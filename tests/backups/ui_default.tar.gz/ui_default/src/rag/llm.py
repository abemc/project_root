import os
import requests
import json
from typing import Optional, List, Dict, Any

# -----------------------------
# LLM 呼び出し
# -----------------------------
def call_llm(prompt: str, model: str = "qwen2.5:7b", system_prompt: Optional[str] = None, chat_history: Optional[List[Dict[str, str]]] = None, stream: bool = False, **kwargs):
    """
    LLMを呼び出す統一インターフェース。
    """
    is_openai_model = model.lower().startswith(("gpt-", "o1-"))
    force_openai = os.environ.get("USE_OPENAI_API", "").lower() == "true"
    
    if is_openai_model or force_openai:
        return _call_openai_compatible(prompt, model, system_prompt, chat_history, stream=stream, **kwargs)
    else:
        return _call_ollama_chat(prompt, model, system_prompt, chat_history, stream=stream, **kwargs)


def _call_ollama_chat(prompt: str, model: str, system_prompt: Optional[str] = None, chat_history: Optional[List[Dict[str, str]]] = None, stream: bool = False, **kwargs):
    """
    Ollama Chat API (/api/chat) を呼び出す。
    """
    base_url = os.environ.get("OLLAMA_BASE_URL", "http://172.18.0.1:11434")
    url = f"{base_url}/api/chat"
    
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    
    if chat_history:
        messages.extend(chat_history)
    
    user_message = {"role": "user", "content": prompt}
    if "images" in kwargs:
        user_message["images"] = kwargs["images"]
    
    messages.append(user_message)

    options = {
        "temperature": kwargs.get("temperature", 0.7),
    }
    max_tokens = kwargs.get("max_tokens", kwargs.get("max_new_tokens", 2048))
    if max_tokens:
        options["num_predict"] = max_tokens

    payload = {
        "model": model,
        "messages": messages,
        "stream": stream,
        "options": options,
        "keep_alive": -1
    }

    try:
        res = requests.post(url, json=payload, stream=stream, timeout=(5, 60))
        res.raise_for_status()
        
        if stream:
            def generator():
                try:
                    for line in res.iter_lines():
                        if line:
                            chunk = json.loads(line.decode('utf-8'))
                            content = chunk.get("message", {}).get("content", "")
                            if content:
                                yield content
                except Exception as e:
                    yield f"Error in stream: {e}"
            return generator()
        else:
            return res.json()["message"]["content"].strip()
            
    except requests.exceptions.RequestException as e:
        print(f"[Error] Request failed: {e}")
        return f"Error: {e}"


def _call_ollama(prompt: str, model: str, **kwargs):
    return _call_ollama_chat(prompt, model, **kwargs)


def _call_openai_compatible(prompt: str, model: str, system_prompt: Optional[str] = None, chat_history: Optional[List[Dict[str, str]]] = None, api_base: Optional[str] = None, stream: bool = False, **kwargs):
    """
    OpenAI Chat Completion API 互換のエンドポイントを呼び出す。
    """
    api_key = os.environ.get("OPENAI_API_KEY")
    base_url = api_base if api_base else os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1")
    
    url = f"{base_url.rstrip('/')}/chat/completions"

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}" if api_key else ""
    }

    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    
    if chat_history:
        messages.extend(chat_history)
        
    messages.append({"role": "user", "content": prompt})
    
    payload = {
        "model": model,
        "messages": messages,
        "temperature": kwargs.get("temperature", 0.7),
        "stream": stream
    }
    
    max_tokens = kwargs.get("max_tokens", kwargs.get("max_new_tokens", 2048))
    if max_tokens:
        payload["max_tokens"] = max_tokens

    try:
        res = requests.post(url, headers=headers, json=payload, stream=stream, timeout=(5, 60))
        res.raise_for_status()
        
        if stream:
            def generator():
                try:
                    for line in res.iter_lines():
                        if line:
                            decoded = line.decode('utf-8').strip()
                            if decoded.startswith("data: "):
                                data_str = decoded[6:]
                                if data_str == "[DONE]":
                                    break
                                try:
                                    chunk = json.loads(data_str)
                                    content = chunk.get("choices", [{}])[0].get("delta", {}).get("content", "")
                                    if content:
                                        yield content
                                except Exception:
                                    pass
                except Exception as e:
                    yield f"Error in stream: {e}"
            return generator()
        else:
            data = res.json()
            return data["choices"][0]["message"]["content"].strip()
            
    except Exception as e:
        error_msg = f"[Error] OpenAI API call failed: {e}"
        print(error_msg)
        return f"Error: {error_msg}"
