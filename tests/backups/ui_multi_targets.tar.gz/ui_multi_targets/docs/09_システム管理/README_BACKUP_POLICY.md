# Backup & Restore Policy (local_backups)

このリポジトリでは、Git 履歴のアーカイブを `local_backups/` に保存し、必要に応じて復元できる運用を採用しています。

主なポイント:
- アーカイブ生成: `scripts/local_backup.sh` または `scripts/auto_local_backup.sh` を使用して `.git` を tar.gz 化します。
- 復元: `scripts/restore_git.sh <archive>` を使って安全に復元できます。手順は `RESTORE_GIT.md` を参照してください。
- 保管: 重要なアーカイブはローカルの `local_backups/` に保存されます。機密性・可用性を確保するために外部ストレージ（S3、外付けHDD 等）へコピーしてください。
- 保持期間: `scripts/auto_local_backup.sh` の `RETENTION_DAYS` 環境変数で日数を設定できます（既定 30 日）。

推奨運用:
- アーカイブ作成後、速やかに外部ストレージへ転送すること（例: `rclone copy local_backups/ remote:backups/project_root`）。
- 大容量ファイルが履歴に含まれる場合、復元後に `git-filter-repo` で履歴から除去すること。
- Git を再利用する場合、リモートへ push する前に履歴を健全化すること（大容量ファイルの除去、`.gitignore` の確認）。
