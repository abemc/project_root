# 相対日付処理の診断ガイド

## ユーザーの報告

「何故、昨日と明記しているのに今日の日付になるのか？」

## 📊 実装状況

実装を確認した結果、コード上は正しく以下のように処理されています：

### 処理フロー（app.py）

```python
# 行2386-2392: 相対日付を具体日付に変換
normalized_query, interpreted_date = parse_relative_date(query)
if interpreted_date:
    _append_run_log(f"date_normalization: original='{query}' normalized='{normalized_query}' interpreted={interpreted_date}")
    query_for_llm = normalized_query  # ← 「2026-05-28」に変換される
else:
    query_for_llm = query

# 行2394: LLM に正規化されたクエリを送付
prompt = _build_query_with_context(query_for_llm)
```

**期待される動作**:
- 入力: 「昨日の試合結果は？」
- 変換: `query_for_llm = "2026-05-28の試合結果は？"`
- LLM 入力: 「2026-05-28の試合結果は？」
- LLM 回答: 「2026年5月28日の試合結果は...」

## 🔍 診断ステップ

### ステップ1: ログで相対日付変換を確認

```bash
# ログを確認するコマンド
tail -100 logs/streamlit_run.log | grep "date_normalization"
```

**期待される出力**:
```
date_normalization: original='昨日の試合結果は？' normalized='2026-05-28の試合結果は？' interpreted=2026-05-28
```

**問題の兆候**:
- ❌ このログが表示されない → 相対日付処理が呼ばれていない
- ❌ 日付が「2026-05-29」になっている → 日付計算が逆

### ステップ2: Streamlit アプリで確認

1. Streamlit アプリを **再起動** してキャッシュをクリア
   ```bash
   # 方法1: ターミナルで Ctrl+C して再起動
   streamlit run app.py
   
   # 方法2: Streamlit UI の「Always rerun」オプションを確認
   ```

2. 「昨日の試合結果は？」と入力

3. ログで確認
   ```bash
   tail -20 logs/streamlit_run.log
   ```

4. LLM の回答を確認
   - ✅ 「2026年5月28日」と答えているか
   - ❌ 「2026年5月29日（今日）」と答えているか

### ステップ3: 複数の相対日付パターンで確認

```
1. 「昨日」→ 期待: 「2026-05-28」
2. 「今日」→ 期待: 「2026-05-29」
3. 「明日」→ 期待: 「2026-05-30」
```

## 🐛 可能な問題と対策

| 症状 | 原因の可能性 | 対策 |
|-----|-----------|------|
| ログに `date_normalization` が表示されない | キャッシュが古い または実装が読み込まれていない | アプリを再起動、ブラウザキャッシュをクリア |
| 日付が「2026-05-29」（今日）になっている | LLM が誤解している | システムプロンプトを確認、再度テスト |
| LLM が「具体的な日付が必要」と答える | `query_for_llm` が LLM に渡されていない | ログで確認、再実装検討 |
| 検索結果が「今日」のデータになっている | Web 検索が日付を誤解している | Web 検索の引数を確認 |

## 📝 実装の詳細確認

### 相対日付変換ロジック（src/rag/date_utils.py）

テスト結果（2026-05-29 現在）:

```
昨日 → 2026-05-28 ✅
今日 → 2026-05-29 ✅
明日 → 2026-05-30 ✅
一昨日 → 2026-05-27 ✅
```

全テストケースが正常に動作していることが確認されました。

### 相対日付使用箇所（app.py）

| 行番号 | 使用箇所 | 正規化クエリ |
|--------|---------|-----------|
| 2394 | LLM プロンプト生成 | ✅ query_for_llm |
| 2410 | 章ヒントクエリ | ✅ query_for_llm |
| 2507 | 初期検索 | ✅ query_for_llm |
| 2523 | ドメイン検出後検索 | ✅ query_for_llm |
| 2617 | Web フォールバック後検索 | ✅ query_for_llm |
| 2700 | 言語検出後検索 | ✅ query_for_llm |
| 2989 | フォールバック retrieval | ✅ query_for_llm |

**結論**: すべての箇所で `query_for_llm` が正しく使用されています。

## 🎯 解決手順

### 解決策 1: キャッシュをリセット

```bash
# Streamlit キャッシュをクリア
rm -rf ~/.streamlit/cache

# Python キャッシュをクリア
find . -type d -name "__pycache__" -exec rm -rf {} +
find . -type f -name "*.pyc" -delete

# アプリを再起動
streamlit run app.py
```

### 解決策 2: ログを詳しく確認

```bash
# 最新の date_normalization ログを確認
tail -50 logs/streamlit_run.log | grep -A 3 "date_normalization"

# llm_input ログと date_normalization ログの関連性を確認
tail -100 logs/streamlit_run.log | grep -E "(date_normalization|llm_input)" | tail -10
```

### 解決策 3: 実装を再検証

```bash
# テストスクリプトを実行
python test_date_debug.py

# 出力で「parse_relative_date() は正常に動作しています」と表示されるか確認
```

## ✅ チェックリスト

- [ ] キャッシュをクリアして Streamlit を再起動した
- [ ] ログで `date_normalization` が正しい日付を記録していることを確認
- [ ] LLM が「具体的な日付が必要」と答えなくなったことを確認
- [ ] 「昨日」「今日」「明日」など複数のパターンで確認した
- [ ] Web 検索でも正しい日付のデータが返されることを確認

## 💡 補足

**システムプロンプト（行2357-2365）**:
```
【相対日付の処理について】
- ユーザーが「昨日」「明日」「今日」などの相対日付を使用した場合、
  システムは既にそれを具体的な日付に変換しています
- 相対日付が具体日付に変換済みであることを前提にして、
  その具体的な日付を用いて回答してください
```

LLM はこのシステムプロンプトに従って、「昨日」を「2026-05-28」として処理すべきです。

## ❓ 問題が解決しない場合

1. ログの最後の100行をファイルに保存
   ```bash
   tail -100 logs/streamlit_run.log > debug_log.txt
   ```

2. 以下の情報を確認
   - date_normalization ログで何に変換されているか
   - llm_input ログで LLM に何が渡されているか
   - call_llm ログで LLM の回答がどうなっているか

3. ログから問題パターンを特定する
