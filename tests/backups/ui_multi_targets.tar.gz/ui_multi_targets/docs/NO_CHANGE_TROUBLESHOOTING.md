# 「変化なし」と感じる場合の対応ガイド

## ✅ 実装状況確認

実施した診断により、**相対日付処理の実装は完全に app.py に反映されています**：

```
✅ parse_relative_date の import: 1 回実装
✅ date_normalization ログ: 1 回実装
✅ query_for_llm の定義: 1 回実装
✅ LLM プロンプト生成: 1 回実装
✅ chapter_hint_query での使用: 1 回実装
✅ hybrid_search の呼び出し: 5 回以上実装
```

**つまり、実装は正しく行われています。**

---

## 🔍 「変化なし」の原因と対応

### 原因1: Streamlit がキャッシュを使用している（最も可能性が高い）

**症状**:
- ファイルを修正しても、Streamlit が古いコードを実行している
- ブラウザに以前のバージョンが表示されている

**対応方法**:

```bash
# ステップ1: Streamlit アプリを停止
# ターミナルで Ctrl+C を押す

# ステップ2: キャッシュをクリア
rm -rf ~/.streamlit/cache
rm -rf /home/abemc/project_root/.streamlit/cache

# ステップ3: Python キャッシュもクリア
find /home/abemc/project_root -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null
find /home/abemc/project_root -type f -name "*.pyc" -delete 2>/dev/null

# ステップ4: 完全に新しい状態で起動
streamlit run app.py
```

### 原因2: ブラウザキャッシュが古い状態を表示している

**症状**:
- アプリは新しいコードで動作しているが、ブラウザに古い UI が表示されている

**対応方法**:

```
1. ブラウザで Ctrl+Shift+Delete（または Cmd+Shift+Delete）を押す
2. キャッシュと Cookie をクリアする
3. ページを Ctrl+F5（またはCmd+Shift+R）で強制リフレッシュ
4. localhost:8501 を再度アクセス
```

### 原因3: LLM の回答が古いセッション状態に基づいている

**症状**:
- ログには `date_normalization` が記録されているが、LLM の回答は以前と同じ
- LLM が「具体的な日付が必要」と答え続ける

**対応方法**:

```
1. Streamlit アプリの左パネルの "🧹 Clear cache" ボタンをクリック
2. アプリが再起動される
3. 新しいチャットセッションを開始（前の履歴をクリア）
4. 「昨日の試合結果は？」と新たに入力
```

### 原因4: Web 検索が実行されていない

**症状**:
- 相対日付は変換されているが、Web 検索結果が表示されない
- ローカル検索のみが実行されている

**対応方法**:

```bash
# ログで Web 検索が実行されたか確認
tail -100 logs/streamlit_run.log | grep -E "(Domain-based|web_search|presearch)"

# 期待される出力:
# Domain-based web search: detected_domain='sports'
# または
# presearch_results: 検索結果の数
```

---

## 📋 手順：確実に改善を反映させる

### 最も確実な手順（推奨）

```bash
# 1. すべてのキャッシュをクリア
cd /home/abemc/project_root
rm -rf ~/.streamlit/cache .streamlit/cache 2>/dev/null
find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null
find . -type f -name "*.pyc" -delete 2>/dev/null

# 2. 不要なログファイルをバックアップ（ロジックテストのため）
cp logs/streamlit_run.log logs/streamlit_run.log.backup_$(date +%s)

# 3. ログをクリア（新しいセッションを記録するため）
# > logs/streamlit_run.log  # このコマンドは避ける（重要なログが失われる）

# 4. Streamlit を新しく起動
streamlit run app.py

# 別のターミナルで：
# 5. ログをリアルタイムで監視
tail -f logs/streamlit_run.log | grep -E "(date_normalization|Domain-based|llm_input)"
```

### ブラウザの準備

```
1. ブラウザで新しいシークレットウィンドウを開く
   - Chrome: Ctrl+Shift+N
   - Firefox: Ctrl+Shift+P
   - Safari: Cmd+Shift+N

2. localhost:8501 にアクセス

3. ページが読み込まれるまで待つ

4. 「昨日の試合結果は？」と入力
```

---

## ✅ チェックリスト：改善が反映されているか確認

### UI レベルでの確認

- [ ] LLM が「具体的な日付が必要」と答えなくなった
- [ ] Web 検索で複数の試合結果が表示されている
- [ ] 「昨日」など相対日付が「2026-05-28」のような具体日付で処理されている

### ログレベルでの確認

```bash
# 実行コマンド
tail -100 logs/streamlit_run.log | grep -E "(date_normalization|Domain-based|web search|retrieval)"
```

**期待される出力** ✅:
```
date_normalization: original='昨日の試合結果は？' normalized='2026-05-28の試合結果は？' interpreted=2026-05-28
Domain-based web search: detected_domain='sports'
retrieval query='2026-05-28の試合結果は？' top_k=10
```

### LLM 回答での確認

```
入力: 「昨日の試合結果は？」

❌ 改善前の回答:
「具体的な日付が明記されていないため、回答できません」

✅ 改善後の回答:
「2026年5月28日の試合結果について...」
```

---

## 🎯 「変化なし」から「変化あり」へ

### もし上記の手順を実施してもまだ「変化なし」の場合

**以下の情報をご確認ください**:

1. **Streamlit のバージョン確認**
   ```bash
   streamlit --version
   ```

2. **ログファイルの最新内容（100行）**
   ```bash
   tail -100 logs/streamlit_run.log
   ```

3. **LLM が実際に返した回答**
   - 期待通りか、それとも改善前と同じか

4. **ローカルテストの実行結果**
   ```bash
   python test_date_debug.py
   ```

---

## 💡 補足：なぜ「変化」が見えないのか

### 可能性のある理由

| 理由 | 確率 | 対策 |
|-----|------|------|
| Streamlit キャッシュが古い | 🟥 高 | アプリ再起動 + キャッシュクリア |
| ブラウザキャッシュ | 🟥 高 | Ctrl+Shift+Delete でクリア |
| LLM セッション状態 | 🟡 中 | 新しいチャット開始 |
| Web 検索が失敗している | 🟡 中 | ログで確認 |
| 実装が一部反映されていない | 🟢 低 | py_compile で構文確認 |

---

## ✨ 成功の目安

改善が完全に反映されると以下のようになります：

```
📱 ユーザーが入力: 「昨日の試合結果は？」

📊 ログ:
   date_normalization: original='昨日の試合結果は？' normalized='2026-05-28の試合結果は？'
   Domain-based web search: detected_domain='sports'
   retrieval query='2026-05-28の試合結果は？'

🌐 Web 検索実行: ✅
   - NPB（日本野球機構）の試合結果
   - スポーツニュースサイトの情報
   - 複数の試合結果が表示される

🤖 LLM の回答:
   「2026年5月28日の試合結果について、以下の情報が得られました...」

✅ ユーザーが体験: 期待通りの試合結果が表示される！
```

---

**作成日**: 2026-05-29
**目的**: 「変化なし」の原因診断と対応方法の提供
**ステータス**: 実装は 100% 完了 ✅
