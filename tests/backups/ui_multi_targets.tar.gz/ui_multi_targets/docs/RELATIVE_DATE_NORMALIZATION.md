# 相対日付処理の改善ドキュメント

## 問題の詳細

ユーザーが「昨日」と入力しても、エージェントが「具体的な日付が明記されていない」と答える問題が発生していました。

### ❌ 改善前の流れ

```
ユーザー入力: "昨日の試合結果は？"
  ↓
app.py _generate_assistant_response()
  ↓
LLMに渡すプロンプト: "昨日の試合結果は？" (そのまま)
  ↓
LLM処理: "具体的な日付が明記されていないため、特定の結果を提供できません"
```

**原因**：
- `parse_relative_date()` で相対日付を変換するコードは存在したが、変換後の結果が使用されていなかった
- LLM に渡されるプロンプトは元のユーザー入力のまま
- 相対日付を処理するロジックが UI 表示のみに使用されていた

### ✅ 改善後の流れ

```
ユーザー入力: "昨日の試合結果は？"
  ↓
parse_relative_date() で相対日付を具体日付に変換
  ↓
変換後: "2026-05-28の試合結果は？"
  ↓
LLMに渡すプロンプト: "2026-05-28の試合結果は？"
  ↓
LLM処理: "2026年5月28日の試合結果は..."
```

## 実装内容

### 1. _generate_assistant_response() 関数の修正

#### 追加コード（行2386-2396）

```python
# 🔧 相対日付を具体日付に変換してから LLM に渡す
normalized_query, interpreted_date = parse_relative_date(query)
if interpreted_date:
    _append_run_log(f"date_normalization: original='{query}' normalized='{normalized_query}' interpreted={interpreted_date}")
    query_for_llm = normalized_query
else:
    query_for_llm = query

prompt = _build_query_with_context(query_for_llm)
```

**処理内容**：
1. `parse_relative_date()` で相対日付を変換
2. 変換成功時は `normalized_query` を `query_for_llm` に設定
3. 変換失敗時は元の `query` を使用
4. ログに変換情報を記録

### 2. 検索クエリの正規化

複数の `hybrid_search()` 呼び出しで、元の `query` の代わりに `query_for_llm` を使用：

- **行2407**: `chapter_hint_query = query_for_llm`
- **行2505**: `retriever.hybrid_search(query_for_llm, ...)`
- **行2523**: `retriever.hybrid_search(query_for_llm, ...)`
- **行2617**: `retriever.hybrid_search(query_for_llm, ...)`
- **行2700**: `retriever.hybrid_search(query_for_llm, ...)`
- **行2989**: `retriever.hybrid_search(query_for_llm, ...)`

**効果**：
- 検索キーワードも具体的な日付を含むようになる
- より関連性の高い検索結果を取得

## テスト結果

実装したテストスクリプト (`test_relative_date_fix.py`) で検証：

### 相対日付の変換テスト

| 入力 | 変換済み | 解釈日付 | 結果 |
|------|---------|---------|------|
| 昨日の試合結果は？ | 2026-05-28の試合結果は？ | 2026-05-28 | ✅ |
| 昨日 | 2026-05-28 | 2026-05-28 | ✅ |
| 明日の天気は？ | 2026-05-30の天気は？ | 2026-05-30 | ✅ |
| 今日は何月何日ですか | 2026-05-29は何月何日ですか | 2026-05-29 | ✅ |
| 一昨日の出来事 | 2026-05-27の出来事 | 2026-05-27 | ✅ |
| この情報について | この情報について | None | ✅ |
| マンドラとは | マンドラとは | None | ✅ |

**結果**：全テストケース成功 ✅

## ログの変化

### 改善前
```
2026-05-29T09:02:18.792750 - retrieval query='昨日の日本ハムファイターズの成績は？'
2026-05-29T09:02:18.793130 - llm_input query='昨日の日本ハムファイターズの成績は？'
```

### 改善後（期待値）
```
2026-05-29T09:02:18.792750 - date_normalization: original='昨日の日本ハムファイターズの成績は？' normalized='2026-05-28の日本ハムファイターズの成績は？' interpreted=2026-05-28
2026-05-29T09:02:18.792750 - retrieval query='2026-05-28の日本ハムファイターズの成績は？'
2026-05-29T09:02:18.793130 - llm_input query='2026-05-28の日本ハムファイターズの成績は？'
```

## システムプロンプトとの整合性

システムプロンプト内の説明：

```
【相対日付の処理について】
- ユーザーが「昨日」「明日」「今日」などの相対日付を使用した場合、
  システムは既にそれを具体的な日付に変換しています
- 相対日付が具体日付に変換済みであることを前提にして、
  その具体的な日付を用いて回答してください
```

**改善前**：この説明が実装と矛盾していた
**改善後**：実装とシステムプロンプトが一致

## 対応する相対日付表現

`parse_relative_date()` が対応する表現：

- **昨日関連**: 昨日、去る日、一日前
- **明日関連**: 明日、翌日、一日後
- **今日**: 今日、本日、当日
- **複数日前**: 一昨日、二日前、三日前
- **複数日後**: 明後日、二日後、三日後
- **曜日を含む**: 昨日の火曜日、明日の月曜日など

## 今後の拡張

1. **より複雑な相対日付**: 「来週」「先月」「今月末」など
2. **曜日からの計算**: 「前の金曜日」「次の月曜日」など
3. **ユーザーのタイムゾーン対応**: 異なるタイムゾーンのユーザーに対応
4. **日付解釈の信頼度**: 曖昧な表現の場合、複数の解釈を提示

## ファイル変更の概要

### 修正ファイル
- **app.py**: `_generate_assistant_response()` 関数内で相対日付の処理を追加

### 追加ファイル
- **test_relative_date_fix.py**: テストスクリプト（検証用）

## バージョン情報

- **実装日**: 2026-05-29
- **Python**: 3.10+
- **テスト状況**: 全テストケース成功 ✅

## トラブルシューティング

### 相対日付が変換されない場合

```bash
# ログを確認
tail -50 logs/streamlit_run.log | grep "date_normalization"

# parse_relative_date 関数の動作を確認
python -c "from src.rag.date_utils import parse_relative_date; print(parse_relative_date('昨日'))"
```

### LLM が相変わらず「具体的な日付が必要」と答える場合

1. システムプロンプトが更新されているか確認
2. `query_for_llm` が正しく `_build_query_with_context()` に渡されているか確認
3. ログで date_normalization が記録されているか確認
