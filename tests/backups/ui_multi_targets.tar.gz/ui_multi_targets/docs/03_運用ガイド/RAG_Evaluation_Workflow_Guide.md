# RAG 評価・回帰ワークフロー 運用ガイド

## 概要

本ガイドは、RAG エージェントの評価・検証・改善の全体ワークフローを実行するための標準的な手順を説明する。以下のツール群が統合され、実装完了している：

- **失敗ケース収集** (`src/evaluation/failure_case_collector.py`)
- **データセット健全性チェック** (`src/evaluation/dataset_sanity_checker.py`)
- **評価差分ビューア** (`src/evaluation/evaluation_diff_viewer.py`)
- **プロンプト回帰テスト** (`src/evaluation/prompt_regression_tester.py`)
- **トレース/根拠ビューア** (`src/evaluation/trace_evidence_viewer.py`)
- **人手レビューキュー** (`src/evaluation/review_queue.py`)
- **夜間ベンチマーク自動実行** (`src/evaluation/nightly_benchmark_runner.py`)
- **Learning Dashboard** (`src/rag/learning_dashboard.py` - RL タブで統合表示)

---

## 1. 環境セットアップ

### 仮想環境の確認

```bash
cd /home/abemc/project_root
source .venv/bin/activate
python --version  # Python 3.10 確認
```

### 依存パッケージのインストール

```bash
pip install -r requirements.txt
```

### 保存ディレクトリの作成

```bash
mkdir -p results/benchmarks
mkdir -p logs/feedback
```

---

## 2. 各ツールの使用方法

### 2.1 失敗ケース収集

**目的**: 誤答・誤引用・ハルシネーションを回帰テストのケースとして保存

**CLI 実行**:

```bash
python -m src.evaluation.failure_case_collector \
  --input evaluation_results.json \
  --output results/failure_cases.jsonl \
  --threshold 0.5 \
  --filter-by groundedness
```

**出力形式** (`results/failure_cases.jsonl`):
```json
{
  "id": "failure-20260601-001",
  "query": "アンソロピック社とは？",
  "expected_answer": "Anthropic は AI 安全企業...",
  "actual_answer": "人材派遣企業",
  "failure_type": "hallucination",
  "confidence_score": 0.25,
  "context": {...},
  "timestamp": "2026-06-01T10:30:00Z"
}
```

**プログラム使用**:
```python
from src.evaluation.failure_case_collector import FailureCaseCollector

collector = FailureCaseCollector(threshold=0.5)
cases = collector.collect(evaluation_results)
collector.save(cases, 'results/failure_cases.jsonl')
```

---

### 2.2 データセット健全性チェック

**目的**: 評価入力の必須キー、データ型、空値、長さ不一致、重複を検出

**CLI 実行**:

```bash
python -m src.evaluation.dataset_sanity_checker \
  --input evaluation_dataset.json \
  --output results/dataset_sanity_report.json \
  --strict
```

**出力形式** (`results/dataset_sanity_report.json`):
```json
{
  "total_items": 100,
  "valid_items": 98,
  "issues": [
    {
      "item_index": 5,
      "issue_type": "missing_field",
      "field": "expected_answer",
      "message": "必須フィールド 'expected_answer' が不足"
    },
    {
      "item_index": 50,
      "issue_type": "length_mismatch",
      "field": "query",
      "current_length": 2000,
      "threshold": 512,
      "message": "クエリが長すぎます"
    }
  ],
  "duplicate_count": 2,
  "duplicate_indices": [3, 25],
  "summary": "98/100 アイテムが有効（98%）"
}
```

**プログラム使用**:
```python
from src.evaluation.dataset_sanity_checker import DatasetSanityChecker

checker = DatasetSanityChecker(strict=True)
report = checker.validate(evaluation_dataset)
checker.save_report(report, 'results/dataset_sanity_report.json')
```

---

### 2.3 評価差分ビューア

**目的**: baseline と current の評価結果を sample 単位で比較し、改善・劣化を検出

**CLI 実行**:

```bash
python -m src.evaluation.evaluation_diff_viewer \
  --baseline results/benchmarks/baseline_20260525.json \
  --current results/benchmarks/current_20260601.json \
  --output results/evaluation_diff.json \
  --threshold 0.1
```

**出力形式** (`results/evaluation_diff.json`):
```json
{
  "baseline_file": "results/benchmarks/baseline_20260525.json",
  "current_file": "results/benchmarks/current_20260601.json",
  "total_samples": 100,
  "improvements": 5,
  "regressions": 2,
  "no_change": 93,
  "sample_diffs": [
    {
      "query_id": "sample-001",
      "query": "今日の日付は？",
      "metric": "groundedness",
      "baseline_score": 0.80,
      "current_score": 0.95,
      "delta": 0.15,
      "category": "improvement",
      "baseline_answer": "...",
      "current_answer": "..."
    }
  ]
}
```

**Learning Dashboard での表示**: RL タブ → 「評価差分」セクション

---

### 2.4 プロンプト回帰テスト

**目的**: プロンプト変更前後で同一ケースを実行し、回帰を検知

**CLI 実行**:

```bash
python -m src.evaluation.prompt_regression_tester \
  --test-cases results/regression_testcases.json \
  --old-prompt prompts/v1.txt \
  --new-prompt prompts/v2.txt \
  --output results/prompt_regression_report.json \
  --llm-model claude-3-sonnet
```

**出力形式** (`results/prompt_regression_report.json`):
```json
{
  "test_case_count": 50,
  "regressions": 2,
  "improvements": 8,
  "no_change": 40,
  "case_comparisons": [
    {
      "case_id": "tc-001",
      "query": "Anthropic について説明してください",
      "old_answer": "...",
      "new_answer": "...",
      "old_score": 0.85,
      "new_score": 0.95,
      "delta": 0.10,
      "status": "improvement"
    }
  ],
  "summary": "新プロンプトは 8 件改善、2 件回帰。全体として改善傾向"
}
```

**プログラム使用**:
```python
from src.evaluation.prompt_regression_tester import PromptRegressionTester

tester = PromptRegressionTester(llm_model='claude-3-sonnet')
report = tester.compare(
    test_cases=cases,
    old_prompt=old_prompt_text,
    new_prompt=new_prompt_text
)
tester.save_report(report, 'results/prompt_regression_report.json')
```

---

### 2.5 トレース/根拠ビューア

**目的**: 1 つの評価ケースについて、検索文書・スコア・回答・メトリクスを迅速に表示

**CLI 実行**:

```bash
python -m src.evaluation.trace_evidence_viewer \
  --query-id sample-001 \
  --evaluation-result results/current_evaluation.json \
  --evidence-store results/evidence_store.jsonl
```

**出力例** (ターミナル表示):
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Query ID: sample-001
Query: "Anthropic について説明してください"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Search Results]
  1. Anthropic Official Site (score: 0.95)
     → AI safety company founded in 2021...
  2. Wikipedia Anthropic (score: 0.87)
     → Anthropic is an American AI company...

[Answer Generated]
Anthropic は AI 安全を重視するスタートアップ...

[Metrics]
  - Groundedness: 0.92 ✓
  - Relevance: 0.88 ✓
  - Completeness: 0.85 ✓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Learning Dashboard での表示**: RL タブ → 「評価差分」→ サンプル選択 → 「詳細を表示」

---

### 2.6 人手レビューキュー

**目的**: 疑わしいケースを queue に登録し、人手で確認・タグ付けしたうえで改善に反映

**CLI 実行**:

```bash
# キューに追加
python -m src.evaluation.review_queue \
  --action add \
  --query-id sample-001 \
  --reason "Groundedness スコアが低い" \
  --priority high

# キューをリスト表示
python -m src.evaluation.review_queue --action list

# レビュー担当者が claim
python -m src.evaluation.review_queue \
  --action claim \
  --review-id rv-001 \
  --reviewer "reviewer@example.com"

# レビュー後に release（完了）
python -m src.evaluation.review_queue \
  --action release \
  --review-id rv-001 \
  --status approved \
  --tags "false-positive" \
  --notes "引用は正確"
```

**保存ファイル** (`logs/feedback/review_queue.jsonl`):
```json
{
  "review_id": "rv-001",
  "query_id": "sample-001",
  "reason": "Groundedness スコアが低い",
  "priority": "high",
  "status": "claimed",
  "claimed_by": "reviewer@example.com",
  "created_at": "2026-06-01T10:30:00Z",
  "claimed_at": "2026-06-01T11:00:00Z",
  "tags": ["false-positive"],
  "notes": "引用は正確"
}
```

**プログラム使用**:
```python
from src.evaluation.review_queue import ReviewQueue

queue = ReviewQueue(storage_path='logs/feedback/review_queue.jsonl')

# キューに追加
queue.add(
    query_id='sample-001',
    reason='Groundedness スコアが低い',
    priority='high'
)

# キューをリスト表示
items = queue.list_items()

# claim
queue.claim('rv-001', reviewer='reviewer@example.com')

# release（完了）
queue.release(
    'rv-001',
    status='approved',
    tags=['false-positive'],
    notes='引用は正確'
)
```

---

### 2.7 夜間ベンチマーク自動実行 + ゲート判定

**目的**: 定期的に評価を実行し、baseline との比較結果を自動保存、回帰ゲートレポートを生成

**CLI 実行**:

```bash
# 標準実行（評価保存のみ）
python -m src.evaluation.nightly_benchmark_runner \
  --benchmark-json evaluation_config.json \
  --output-dir results/benchmarks

# 自動ゲート判定を含める
python -m src.evaluation.nightly_benchmark_runner \
  --benchmark-json evaluation_config.json \
  --output-dir results/benchmarks \
  --auto-gate \
  --gate-threshold 0.05 \
  --notify-slack https://hooks.slack.com/services/...
```

**出力ファイル**:
- `results/benchmarks/benchmark_20260601_103000.json` - 評価結果
- `results/benchmarks/regression_gate_report_20260601.json` - ゲート判定レポート
- Slack 通知（`--notify-slack` 時）

**保存されるゲートレポート** (`results/benchmarks/regression_gate_report_20260601.json`):
```json
{
  "timestamp": "2026-06-01T10:30:00Z",
  "baseline_file": "results/benchmarks/baseline_20260525.json",
  "current_file": "results/benchmarks/benchmark_20260601_103000.json",
  "metrics": {
    "groundedness": {
      "baseline_mean": 0.85,
      "current_mean": 0.87,
      "delta": 0.02,
      "status": "PASS"
    },
    "relevance": {
      "baseline_mean": 0.88,
      "current_mean": 0.86,
      "delta": -0.02,
      "status": "WARN"
    }
  },
  "overall_status": "PASS",
  "message": "2 改善、0 回帰。ゲートクリア"
}
```

**プログラム使用**:
```python
from src.evaluation.nightly_benchmark_runner import NightlyBenchmarkRunner

runner = NightlyBenchmarkRunner(output_dir='results/benchmarks')

# 評価実行
result = runner.run_benchmark(benchmark_config)

# 自動ゲート判定
if runner.auto_gate:
    gate_report = runner.check_regression_gate(
        baseline=result['baseline'],
        current=result['current'],
        threshold=0.05
    )
    print(f"Gate Status: {gate_report['overall_status']}")
```

---

### 2.8 Learning Dashboard での統合表示

**起動**:
```bash
streamlit run src/rag/learning_dashboard.py --logger.level=debug
```

**RL タブの表示内容**:
1. **評価歴**
   - 最近 10 回の評価実行日時とメトリクス推移

2. **評価差分**（新規追加）
   - baseline と current の比較
   - 改善/回帰のサンプル数
   - サンプル単位の詳細差分表示

3. **ケース詳細ジャンプ**（新規追加）
   - 差分表示から任意のサンプルを選択
   - トレースビューア機能で検索文書・スコア・回答を表示

4. **Feedback 統計**
   - 直近 24 時間のユーザーフィードバック件数
   - Latest Feedback 詳細表示

---

## 3. 実行フロー

### 定期実行の推奨スケジュール

| ツール | 実行頻度 | 実行時刻 | 出力先 |
|---|---|---|---|
| 夜間ベンチマーク | 日1回 | 00:00 UTC | `results/benchmarks/` |
| データセット健全性チェック | 週1回 | 日曜 00:00 | `results/dataset_sanity_*` |
| プロンプト回帰テスト | 月1回（変更時） | 手動実行 | `results/prompt_regression_*` |
| 人手レビューキュー確認 | 日1回 | 10:00 UTC | Dashboard UI |

### 例：日次 CI/CD パイプライン

```bash
#!/bin/bash
# deploy/run_nightly_pipeline.sh

set -e
cd /home/abemc/project_root
source .venv/bin/activate

# 1. 評価実行 + 自動ゲート判定
echo "[Step 1] Running nightly benchmark..."
python -m src.evaluation.nightly_benchmark_runner \
  --benchmark-json config/rag_agent_config.json \
  --output-dir results/benchmarks \
  --auto-gate \
  --notify-slack "$(cat .slack_webhook)"

# 2. データセット健全性チェック（週1回の場合、曜日確認）
if [ "$(date +%w)" = "0" ]; then
  echo "[Step 2] Running dataset sanity check..."
  python -m src.evaluation.dataset_sanity_checker \
    --input config/dataset_registry.json \
    --output results/dataset_sanity_report.json
fi

# 3. 失敗ケース収集
echo "[Step 3] Collecting failure cases..."
LATEST_RESULT=$(ls -t results/benchmarks/benchmark_*.json | head -1)
python -m src.evaluation.failure_case_collector \
  --input "$LATEST_RESULT" \
  --output results/failure_cases.jsonl \
  --threshold 0.5

echo "[Success] Nightly pipeline completed"
```

---

## 4. systemd による自動実行設定

### タイマーユニットの作成

ファイル: `/etc/systemd/system/rag-nightly-pipeline.timer`

```ini
[Unit]
Description=RAG Nightly Evaluation Pipeline
After=network.target

[Timer]
OnCalendar=daily
OnCalendar=*-*-* 00:00:00
Persistent=true
AccuracySec=1min

[Install]
WantedBy=timers.target
```

### サービスユニットの作成

ファイル: `/etc/systemd/system/rag-nightly-pipeline.service`

```ini
[Unit]
Description=RAG Nightly Evaluation Pipeline
After=network.target

[Service]
Type=oneshot
User=abemc
WorkingDirectory=/home/abemc/project_root
Environment="PATH=/home/abemc/.pyenv/versions/3.10.13/bin:/usr/local/bin:/usr/bin"
ExecStart=/home/abemc/project_root/deploy/run_nightly_pipeline.sh
StandardOutput=journal
StandardError=journal
SyslogIdentifier=rag-nightly

[Install]
WantedBy=multi-user.target
```

### 有効化と起動

```bash
# タイマーユニットを有効化
sudo systemctl enable rag-nightly-pipeline.timer
sudo systemctl start rag-nightly-pipeline.timer

# ステータス確認
sudo systemctl status rag-nightly-pipeline.timer
systemctl list-timers rag-nightly-pipeline.timer

# ログ確認
journalctl -u rag-nightly-pipeline.service -f
```

---

## 5. トラブルシューティング

### テストの実行方法

```bash
# 全テスト実行
python -m pytest tests/test_evaluation_*.py -q

# 特定ツールのテストのみ
python -m pytest tests/test_dataset_sanity_checker.py -v
python -m pytest tests/test_prompt_regression_tester.py -v
python -m pytest tests/test_review_queue.py -v
python -m pytest tests/test_nightly_benchmark_runner.py -v
```

### よくあるエラー

**エラー**: `FileNotFoundError: evaluation_dataset.json`
- **原因**: 入力ファイルのパスが正しくない
- **対応**: 絶対パスを使用するか、相対パスの基準ディレクトリを確認

**エラー**: `KeyError: 'groundedness'`
- **原因**: 評価結果に必須メトリクスが不足
- **対応**: `DatasetSanityChecker` でデータセット検証を実行し、問題を特定

**エラー**: Slack 通知が失敗
- **原因**: Webhook URL が無効または期限切れ
- **対応**: `.slack_webhook` ファイルが存在し、正しい URL が含まれているか確認

---

## 6. ベストプラクティス

1. **定期的なバックアップ**
   - `results/benchmarks/` と `logs/` を週1回バックアップ
   - 回帰ゲート履歴は 90 日以上保持

2. **レビューキューの活用**
   - 疑わしいケースは即座にレビューキューに登録
   - 優先度を適切に設定し、対応順序を効率化

3. **プロンプト変更時の検証**
   - 変更前に `PromptRegressionTester` を実行
   - ゲートレポートで改善/回帰を明確にしてから本番投入

4. **ダッシュボードの定期確認**
   - 1 日 1 回は RL タブの差分と最新フィードバックをチェック
   - 異常傾向を早期に検知

---

## 7. サポート

問題が発生した場合、以下を確認してください：
- テストログ: `logs/pytest_run.log`
- ダッシュボードエラー: `logs/streamlit_run.log`
- 夜間ジョブログ: `journalctl -u rag-nightly-pipeline.service`

詳細は `docs/02_実装計画/不足ツール強化_作業計画書.md` を参照。
