# RAG 評価ツール テスト・検証ガイド

## 概要

本ドキュメントは、RAG 評価・回帰ワークフロー全体を構成する各ツールのテスト・検証方法を説明する。

実装されたツール：
- 失敗ケース収集 (`src/evaluation/failure_case_collector.py`)
- データセット健全性チェック (`src/evaluation/dataset_sanity_checker.py`)
- 評価差分ビューア (`src/evaluation/evaluation_diff_viewer.py`)
- プロンプト回帰テスト (`src/evaluation/prompt_regression_tester.py`)
- トレース/根拠ビューア (`src/evaluation/trace_evidence_viewer.py`)
- 人手レビューキュー (`src/evaluation/review_queue.py`)
- 夜間ベンチマーク自動実行 (`src/evaluation/nightly_benchmark_runner.py`)

---

## 1. 環境セットアップ

### 仮想環境の有効化

```bash
cd /home/abemc/project_root
source .venv/bin/activate
```

### pytest のインストール確認

```bash
pip install pytest pytest-cov
python -m pytest --version
```

---

## 2. 単体テスト

### 2.1 失敗ケース収集テスト

**テストファイル**: `tests/test_failure_case_collector.py`

実行:
```bash
python -m pytest tests/test_failure_case_collector.py -v
```

テスト内容：
- 正常なケース収集（複数の失敗タイプ）
- スレッショルド判定
- JSON 保存形式の検証
- 空の入力処理

**期待結果**: `✓ passed`

---

### 2.2 データセット健全性チェックテスト

**テストファイル**: `tests/test_dataset_sanity_checker.py`

実行:
```bash
python -m pytest tests/test_dataset_sanity_checker.py -v
```

テスト内容：
- 必須フィールド検出
- データ型チェック
- 長さ不一致検出
- 重複検出
- レポート保存

**期待結果**: `✓ 5 passed`

**サンプル実行**:
```python
from src.evaluation.dataset_sanity_checker import DatasetSanityChecker

checker = DatasetSanityChecker(strict=True)

# テストデータ
dataset = [
    {
        "query": "What is Anthropic?",
        "expected_answer": "Anthropic is an AI company...",
        "ground_truth_documents": ["doc1.txt", "doc2.txt"]
    },
    {
        "query": "Tell me about...",
        # missing expected_answer - should trigger error
        "ground_truth_documents": []
    }
]

report = checker.validate(dataset)
print(f"Valid items: {report['valid_items']}/{report['total_items']}")
# Expected: "Valid items: 1/2"
```

---

### 2.3 評価差分ビューアテスト

**テストファイル**: `tests/test_evaluation_diff_viewer.py`

実行:
```bash
python -m pytest tests/test_evaluation_diff_viewer.py -v
```

テスト内容：
- baseline vs current 比較
- 改善/回帰/不変の分類
- サンプル単位の詳細差分
- JSON レポート保存

**期待結果**: `✓ passed`

**サンプル実行**:
```python
from src.evaluation.evaluation_diff_viewer import EvaluationDiffViewer

viewer = EvaluationDiffViewer(threshold=0.05)

baseline = {
    "results": [
        {
            "query_id": "q1",
            "query": "What is Anthropic?",
            "groundedness": 0.80,
            "relevance": 0.85
        }
    ]
}

current = {
    "results": [
        {
            "query_id": "q1",
            "query": "What is Anthropic?",
            "groundedness": 0.92,
            "relevance": 0.85
        }
    ]
}

diff = viewer.compare(baseline, current)
print(f"Improvements: {diff['improvements']}, Regressions: {diff['regressions']}")
# Expected: "Improvements: 1, Regressions: 0"
```

---

### 2.4 プロンプト回帰テストテスト

**テストファイル**: `tests/test_prompt_regression_tester.py`

実行:
```bash
python -m pytest tests/test_prompt_regression_tester.py -v
```

テスト内容：
- 古プロンプト vs 新プロンプト比較
- LLM 呼び出し（モック）
- 回帰/改善判定
- JSON レポート保存

**期待結果**: `✓ passed`

---

### 2.5 トレース/根拠ビューアテスト

**テストファイル**: `tests/test_trace_evidence_viewer.py`

実行:
```bash
python -m pytest tests/test_trace_evidence_viewer.py -v
```

テスト内容：
- ケース単位のトレース構築
- 検索文書・スコア表示
- フォーマット出力
- ターミナル表示

**期待結果**: `✓ passed`

**サンプル実行** (ターミナル出力):
```bash
python -m src.evaluation.trace_evidence_viewer \
  --query-id sample-001 \
  --evaluation-result results/current_evaluation.json

# Output:
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Query ID: sample-001
# Query: What is Anthropic?
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# [Search Results]
#   1. Anthropic Official (score: 0.95)
#      → AI safety company...
# [Answer]
# Anthropic is an AI company...
# [Metrics]
#   - Groundedness: 0.92 ✓
```

---

### 2.6 人手レビューキューテスト

**テストファイル**: `tests/test_review_queue.py`

実行:
```bash
python -m pytest tests/test_review_queue.py -v
```

テスト内容：
- キューへのアイテム追加
- リスト表示
- claim/release 操作
- JSONL 保存形式の検証
- 状態遷移

**期待結果**: `✓ passed`

**サンプル実行**:
```python
from src.evaluation.review_queue import ReviewQueue
import tempfile

with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl') as f:
    queue = ReviewQueue(storage_path=f.name)
    
    # Add item
    review_id = queue.add(
        query_id='sample-001',
        reason='Low groundedness',
        priority='high'
    )
    print(f"Added review: {review_id}")
    
    # List items
    items = queue.list_items()
    print(f"Queue size: {len(items)}")
    # Expected: "Queue size: 1"
    
    # Claim
    queue.claim(review_id, reviewer='alice@example.com')
    
    # Release
    queue.release(
        review_id,
        status='approved',
        tags=['false-positive'],
        notes='Citation is accurate'
    )
    
    # Verify final state
    final_items = queue.list_items()
    print(f"Final status: {final_items[0]['status']}")
    # Expected: "Final status: released"
```

---

### 2.7 夜間ベンチマーク自動実行テスト

**テストファイル**: `tests/test_nightly_benchmark_runner.py`

実行:
```bash
python -m pytest tests/test_nightly_benchmark_runner.py -v
```

テスト内容：
- ベンチマーク実行
- ファイル保存
- 回帰ゲート判定（2 ファイル比較）
- タイムスタンプ処理
- レポート生成

**期待結果**: `✓ passed`

**サンプル実行** (手動):
```bash
# Create sample benchmark config
cat > /tmp/test_benchmark.json << 'EOF'
{
  "test_cases": [
    {
      "query": "What is Anthropic?",
      "expected_answer": "Anthropic is an AI company..."
    }
  ]
}
EOF

# Run nightly benchmark
python -m src.evaluation.nightly_benchmark_runner \
  --benchmark-json /tmp/test_benchmark.json \
  --output-dir /tmp/benchmark_results

# Check output
ls -la /tmp/benchmark_results/
```

---

## 3. 統合テスト

### 3.1 Learning Dashboard 統合テスト

**テストファイル**: `tests/test_learning_dashboard.py`

実行:
```bash
python -m pytest tests/test_learning_dashboard.py::test_reinforcement_dashboard_shows_evaluation_diff_section -v
```

テスト内容：
- 評価差分セクション表示
- トレースビューア統合
- UI ウィジェット（selectbox、expander、text）の動作

**期待結果**: `✓ passed`

---

### 3.2 エンドツーエンドテスト

### ユーザーフロー（手動確認）

1. **ダッシュボード起動**:
   ```bash
   streamlit run src/rag/learning_dashboard.py
   ```

2. **RL タブを開く**

3. **評価差分セクションを確認**:
   - baseline と current のメトリクス差分が表示されているか
   - 改善/回帰のサンプル数が正しいか

4. **詳細表示をテスト**:
   - サンプルを選択して「詳細を表示」をクリック
   - トレース情報（検索文書、スコア、回答）が表示されるか

5. **Feedback 統計を確認**:
   - 最近のフィードバック件数が表示されているか

---

## 4. 回帰テスト

### 4.1 全テストスイート実行

```bash
# 全テスト（関連する評価ツール）
python -m pytest tests/test_dataset_sanity_checker.py \
                 tests/test_evaluation_diff_viewer.py \
                 tests/test_prompt_regression_tester.py \
                 tests/test_trace_evidence_viewer.py \
                 tests/test_review_queue.py \
                 tests/test_nightly_benchmark_runner.py \
                 tests/test_learning_dashboard.py \
                 -v

# または
python -m pytest -k "sanity_checker or diff_viewer or regression_tester or trace_viewer or review_queue or nightly_runner or learning_dashboard" -v
```

### 4.2 カバレッジ測定

```bash
python -m pytest tests/test_evaluation_*.py --cov=src/evaluation --cov-report=html

# Open coverage report
open htmlcov/index.html
```

### 4.3 パフォーマンステスト

大量ケース（1000+ サンプル）での処理時間測定：

```bash
cat > /tmp/perf_test.py << 'EOF'
import time
from src.evaluation.dataset_sanity_checker import DatasetSanityChecker

# Generate 1000 test items
dataset = []
for i in range(1000):
    dataset.append({
        "query": f"Query {i}",
        "expected_answer": f"Answer {i}",
        "ground_truth_documents": ["doc1.txt", "doc2.txt"]
    })

checker = DatasetSanityChecker()
start = time.time()
report = checker.validate(dataset)
elapsed = time.time() - start

print(f"Validated {report['total_items']} items in {elapsed:.2f}s")
print(f"Rate: {report['total_items']/elapsed:.0f} items/sec")
EOF

python /tmp/perf_test.py
```

---

## 5. CI/CD パイプラインテスト

### 5.1 GitHub Actions ワークフロー

**ファイル**: `.github/workflows/pytest.yml`

このワークフローは以下を実行：
- Python 3.10 環境セットアップ
- 依存パッケージのインストール
- `python -m pytest -q` 全テスト実行

トリガー：
- push to `main` / `master`
- pull requests to `main` / `master`

ローカルで動作確認:
```bash
# act ツール（GitHub Actions 互換）を使用
# or
act -j test -P ubuntu-latest=ghcr.io/catthehacker/ubuntu:latest
```

### 5.2 手動トリガー

```bash
# GitHub CLI でワークフロー実行
gh workflow run pytest.yml -r feature/learning-materials
```

---

## 6. トラブルシューティング

### テスト失敗時の確認項目

1. **環境確認**:
   ```bash
   python --version  # 3.10 であること
   pip list | grep pytest
   ```

2. **テストログ確認**:
   ```bash
   python -m pytest tests/test_*.py -v --tb=short
   ```

3. **特定テストのデバッグ**:
   ```bash
   python -m pytest tests/test_dataset_sanity_checker.py::test_missing_field -vvs
   ```

4. **一時ファイル削除**:
   ```bash
   rm -rf .pytest_cache __pycache__ results/
   ```

### よくあるエラーと対応

| エラー | 原因 | 対応 |
|---|---|---|
| `ModuleNotFoundError` | 仮想環境が有効化されていない | `source .venv/bin/activate` |
| `FileNotFoundError` | テスト入力ファイルが見つからない | `results/` ディレクトリを確認 |
| `AssertionError` | テストアサーション失敗 | `--tb=short` で詳細メッセージ確認 |
| `Timeout` | テスト実行時間が長い | テスト内の LLM モック設定を確認 |

---

## 7. テスト結果レポート

### テスト実行後の確認

```bash
python -m pytest tests/test_evaluation_*.py -q --tb=no

# Expected output:
# ............................ [ 84%]
# ............................ [100%]
# 42 passed in 5.23s
```

### HTML レポート生成

```bash
pip install pytest-html
python -m pytest tests/test_evaluation_*.py --html=report.html --self-contained-html
open report.html
```

---

## 8. デバッグモード

### 詳細ログを有効化

```bash
# レベル DEBUG でテスト実行
export LOG_LEVEL=DEBUG
python -m pytest tests/test_dataset_sanity_checker.py -vv --log-cli-level=DEBUG
```

### インタラクティブデバッグ

```bash
# pdb でテストを実行
python -m pytest tests/test_dataset_sanity_checker.py --pdb

# 最初の失敗時に停止
python -m pytest tests/test_dataset_sanity_checker.py -x --pdb
```

---

## 参考資料

- pytest 公式ドキュメント: https://docs.pytest.org/
- テストベストプラクティス: `docs/06_テスト・検証/テストガイド.md`
- 実装計画書: `docs/02_実装計画/不足ツール強化_作業計画書.md`
- 運用ガイド: `docs/03_運用ガイド/RAG_Evaluation_Workflow_Guide.md`
