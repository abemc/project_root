演習解答（解説付き）

問題1 解答:
- a·b = 1*4 + 2*0 + 3*(-1) = 4 + 0 -3 = 1

問題2 解答（手計算）:
- x = [0,1,2,3], y = [1,3,5,7]
- 観察: y increases by +2 per x → 傾き a = 2
- 切片 b: when x=0, y=1 → b = 1
- したがって y = 2x + 1

問題3 解答（scikit-learn）:
```python
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)
preds = model.predict(X_test)
print('accuracy:', accuracy_score(y_test, preds))
```
- 期待される精度は高め（0.9前後）だが、環境により変動。

問題4 解答:
- テスト関数は `return` を使うと pytest はテストが `None` を返すことを期待しているため警告が出る。正しくは `assert` を使い、期待値と比較する。

正しい例:
```python
def test_example():
    result = func_under_test()
    assert result == expected_value
```

