# 検索品質改善の実装ドキュメント

## 問題の詳細

ユーザーが「試合結果は？」というスポーツ関連クエリを入力した場合：

### ❌ 改善前の動作
```
retrieval query='試合結果は？' top3=[
  {"id": "up_5554", "source": "Raut R. Generative Adversarial Networks and Deep Learning 2023.pdf", "score": 0.01639344262295082},
  {"id": "web_37116", "source": "マンドラ - Wikipedia", "score": 0.01639344262295082},
  {"id": "up_2138", "source": "Pattanayak S. Pro Deep Learning with TensorFlow 2.0...in Python 2ed 2023.pdf", "score": 0.016129032258064516}
]
```

**問題点**：
1. スコア 0.0164 という極めて低い値で結果が返されている
2. 試合結果と全く無関係な「マンドラのWikipedia」が返されている
3. Corpus にスポーツ情報が含まれていないため、機械学習の本が返される

### ✅ 改善後の動作
```
1. ドメイン判定: "試合" キーワードから sports ドメインを検出
2. Local search が空: true
3. Web検索を自動実行
4. Web検索から適切なスポーツ関連のニュースを取得
```

## 実装内容

### 1. retriever.py の修正

#### `hybrid_search()` メソッドにスコア閾値を追加

```python
def hybrid_search(self, query: str, top_k: int = 5, source_filter: str = None, min_score: float = 0.1):
    # ... 既存の処理 ...
    
    # スコア閾値チェック: 低スコア結果を除外
    if doc_scores[doc_id] < min_score:
        print(f"[DBG hybrid_search] Filtering out low-score result: {doc_id} (score={doc_scores[doc_id]:.4f} < min={min_score})")
        continue
    
    final_results.append(doc)
```

**パラメータ**：
- `min_score: float = 0.1` - スコア閾値。この値以下の結果は除外

**効果**：
- スコア 0.1 未満の無関係なドキュメントを自動除外
- 空の検索結果がフォールバック処理を自動トリガー

### 2. app.py の修正

#### 2-1. ドメイン判定ロジックの追加

```python
# ドメイン判定: Web検索の優先化が必要なクエリを検出
sports_keywords = ["試合", "結果", "得点", "勝負", "スコア", "野球", "サッカー", "相撲", "格闘技", ...]
news_keywords = ["最新", "ニュース", "速報", "今日", "昨日", "今週", "事件", "事故", "株価", ...]
real_time_keywords = ["現在", "今", "予報", "天気", "温度", "ライブ", "中継", ...]

detected_domain = None
if any(kw in query for kw in sports_keywords):
    detected_domain = "sports"
elif any(kw in query for kw in news_keywords):
    detected_domain = "news"
elif any(kw in query for kw in real_time_keywords):
    detected_domain = "realtime"
```

**判定ドメイン**：
- `"sports"`: 野球、サッカーなどのスポーツ結果・得点情報
- `"news"`: ニュース速報、最新情報、事件・事故
- `"realtime"`: 天気予報、株価、ライブ中継

#### 2-2. ドメイン別 Web検索フォールバック

```python
# ドメイン検出時に Web検索を優先
if detected_domain and web_search_available and not local_pre:
    try:
        _append_run_log(f"Domain-based web search: detected_domain='{detected_domain}' for query='{query}'")
        web_results = search_web_tool(query, max_results=10)
        if web_results and isinstance(web_results, list):
            local_pre = web_results[:top_k]
            _append_run_log(f"Domain web search retrieved {len(local_pre)} results")
    except Exception as e:
        _append_run_log(f"Domain web search failed: {e}")
```

#### 2-3. ローカル検索が空の場合の Web検索フォールバック

```python
# Web検索の優先化: ローカル検索が空またはスコアが非常に低い場合
if not local_pre and web_search_available:
    try:
        _append_run_log(f"Fallback to web search: local results empty for query='{query}'")
        web_results = search_web_tool(query, max_results=8)
        if web_results and isinstance(web_results, list):
            local_pre = web_results[:top_k]
            _append_run_log(f"Web search retrieved {len(local_pre)} results")
    except Exception as e:
        _append_run_log(f"Web search fallback failed: {e}")
```

## テスト結果

実装したテストスクリプト (`test_search_quality.py`) により検証：

✅ **テスト1: スコア閾値フィルタリング**
- `min_score` パラメータが正常に追加
- デフォルト値 0.1 で低スコア結果を除外

✅ **テスト2: ドメイン判定**
- スポーツ、ニュース、リアルタイムの各キーワードが実装
- ドメイン判定ロジックが動作

✅ **テスト3: Web検索フォールバック**
- ローカル検索が空の場合、Web検索を自動実行
- ドメイン別フォールバック機能も確認

✅ **テスト4: 実シナリオ検証**
- 「試合結果は？」→ sports ドメイン検出 → Web検索優先
- 「マンドラとは？」→ ドメイン未検出 → local search のみ
- 「今週のニュース？」→ news ドメイン検出 → Web検索優先

## 使用例

### ケース1: スポーツ関連クエリ

```
ユーザー: 「昨日の日本ハムファイターズの試合結果は？」

処理フロー:
1. ドメイン判定: "試合", "結果" から sports を検出
2. Local hybrid_search() 実行 → 結果なし or 低スコア
3. Web検索をトリガー
4. 最新の試合結果を Web から取得し、LLM で要約
```

### ケース2: 知識ベース内容のクエリ

```
ユーザー: 「マンドラとは？」

処理フロー:
1. ドメイン判定: 該当キーワードなし → detected_domain = None
2. Local hybrid_search() で corpus から検索
3. 該当ドキュメントがあれば返す
4. Web検索は実行されない（local search を優先）
```

### ケース3: ニュース関連クエリ

```
ユーザー: 「今週のテック系ニュースで何が起こった？」

処理フロー:
1. ドメイン判定: "今週", "ニュース" から news を検出
2. Local search 実行 → 結果なし or 古い情報のみ
3. Web検索をトリガー
4. 最新のニュース記事を取得
```

## ログの読み方

改善後のログには以下のような情報が記録されます：

```
2026-05-29T09:03:14 - Domain-based web search: detected_domain='sports' for query='試合結果は？'
2026-05-29T09:03:14 - Domain web search retrieved 8 results
2026-05-29T09:03:14 - retrieval query='試合結果は？' top3=[{"id": "web_1", "score": 1.0}, ...]
```

## パフォーマンス

- **スコア計算**: 新規ドキュメントの除外により、不要な結果フィルタリング時間を削減
- **Web検索**: ドメイン検出により、適切な場合にのみ Web 検索を実行
- **レスポンス時間**: 無関係な結果の処理を回避し、高速化

## トラブルシューティング

### Web検索結果が返されない場合

```bash
# ログを確認
tail -50 logs/streamlit_run.log | grep -i "web\|domain"

# 必要に応じて search_web_tool の可用性を確認
grep "web_search_available\|search_web_tool" app.py | head -5
```

### スコア閾値を調整したい場合

```python
# app.py 内の hybrid_search() 呼び出しで min_score を指定
local_pre = retriever.hybrid_search(query, top_k=top_k, min_score=0.15)
```

## 今後の拡張

1. **スコア閾値の動的調整**: ドメイン別に異なる閾値を使用
2. **キーワード追加**: スポーツ以外のドメイン（医療、法律など）への対応
3. **L** リーダーボード: Web検索結果の信頼度スコアを追加
4. **キャッシング**: 最近の検索結果をキャッシュして Web 呼び出しを削減

## ファイル変更の概要

### 変更されたファイル
- **src/rag/retriever.py**: `hybrid_search()` メソッドに `min_score` パラメータ追加
- **app.py**: ドメイン判定とWeb検索フォールバック機能を `_generate_assistant_response()` に追加

### 追加ファイル
- **test_search_quality.py**: テストスクリプト（検証用）

## バージョン情報

- **実装日**: 2026-05-29
- **Python**: 3.10+
- **Streamlit**: 1.x
- **テスト状況**: 全テストケース成功 ✅
