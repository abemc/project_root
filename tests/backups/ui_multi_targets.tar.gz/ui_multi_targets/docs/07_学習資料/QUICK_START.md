# ⚡ クイックスタートガイド

このプロジェクトを**最短3日で理解する**ためのガイドです。

---

## 📋 初日（Day 1）- 全体像をつかむ

### 🕐 時間: 2-3時間

#### Step 1️⃣: 環境チェック（15分）
```bash
# 学習環境がセットアップできているか確認
python /home/abemc/project_root/docs/07_学習資料/2026-05-20_自己学習専用版/examples/_utility/test_llm_env.py
```

**問題が出た場合**：[TROUBLESHOOTING.md](TROUBLESHOOTING.md) を参照

---

#### Step 2️⃣: プロジェクト全体を理解（30-45分）

**読む順序**：
1. [02_project_overview/README.md](02_project_overview/README.md) - **この順で読む**
2. 02_project_overview/diagram.pdf (reference: 02_project_overview/diagram.pdf) - ビジュアルで確認

**達成目標**：
- ✅ このプロジェクトが何をするのか説明できる
- ✅ 主要なコンポーネント（RAG, LLM, 検索）が分かる

---

#### Step 3️⃣: LLMの基本概念を学ぶ（60-90分）

**読む順序**：
1. [01_LLM_basics/README.md](01_LLM_basics/README.md) を読む
2. 分からない部分は [01_LLM_basics/content.pdf](01_LLM_basics/content.pdf) で図解を確認

**達成目標**：
- ✅ LLMとは何か、説明できる
- ✅ Transformerアーキテクチャの大枠が分かる

---

## 🗓️ 2日目-3日目（Day 2-3） - コーディング開始

### 🕐 時間: 4-5時間/日

#### Step 1️⃣: セットアップと初実装（2時間）
[03_setup_hands_on/README.md](03_setup_hands_on/README.md) に従って：
- ✅ 開発環境の確認
- ✅ 初期実装コードの実行

---

#### Step 2️⃣: 実装演習で手を動かす（2-3時間）

**各日の推奨タスク**:

**Day 2:**
```
2026-05-20_自己学習専用版/examples/_basic_intro/
├─ 内積_初級.ipynb（45分）
└─ intro.ipynb（45分）
```

**Day 3:**
```
2026-05-20_自己学習専用版/examples/_basic_intro/
└─ llm_hands_on.ipynb（60-90分）
```

**達成目標**：
- ✅ Jupyter Notebookで実装を追える
- ✅ 内積、ベクトル操作が理解できている

---

## 📊 初期3日後の状態

| 項目 | 状態 |
|------|------|
| プロジェクト全体像 | ✅ 理解できた |
| LLM基礎 | ✅ 大枠は分かった |
| コーディング環境 | ✅ 動作確認済 |
| 実装演習 | ✅ 3つのNotebook実行済 |
| 次のステップ | 🔵 中級演習へ |

---

## 🎯 初日に詰まった場合

| 問題 | 対応 |
|------|------|
| `test_llm_env.py` がエラー | [TROUBLESHOOTING.md#環境構築](TROUBLESHOOTING.md#環境構築) |
| PDFが開かない | ブラウザで開くか、テキストのREADMEで対応 |
| Notebookでimport error | [TROUBLESHOOTING.md#実行時エラー](TROUBLESHOOTING.md#実行時エラー) |
| 理解が追いつかない | [PREREQUISITES.md#前提知識が不足している場合](PREREQUISITES.md) |

---

## 📚 次のステップ（Day 4以降）

3日目を完了したら：

### オプション A: 中級への進行（推奨）
[2026-05-20_自己学習専用版/examples/_intermediate_topics/](2026-05-20_自己学習専用版/examples/_intermediate_topics/INDEX.md) 
→ Attentionメカニズムを深掘り

### オプション B: 数学基礎の補強
[foundation_math/](foundation_math/INDEX.md) 
→ ベクトル、行列操作を完全理解

### オプション C: プロジェクトコードの読解
[03_setup_hands_on/README.md](03_setup_hands_on/README.md) の「実装コード読破」セクション
→ 実際のプロジェクトコードを理解

---

## 💡 学習を進めるコツ

✅ **各ステップを順序通りに進める**  
スキップすると後で混乱します。

✅ **分からないことはメモする**  
「Day 5に確認」という未処理リストを作ると、学習が加速します。

✅ **Notebookは実行して確認**  
「読む」だけでなく「実行」してください。出力を見ると理解が深まります。

✅ **30分詰まったら別リソースに切り替える**  
同じことで詰まるより、別の教材から学ぶ方が効率的です。

---

## 🔗 関連ドキュメント

- [PREREQUISITES.md](PREREQUISITES.md) - 前提知識・環境チェック
- [LEARNING_TIMELINE.md](LEARNING_TIMELINE.md) - 中長期の学習計画
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - よくあるエラーと対応
- [README.md](README.md) - 全体ガイド

---

**所要時間目安**: 初日 2-3時間、Day 2-3 各 4-5時間  
**完了時間**: 約 10-13時間

このガイドを完了したら、次は [LEARNING_TIMELINE.md](LEARNING_TIMELINE.md) で 1週間以降の計画を立ててください。
