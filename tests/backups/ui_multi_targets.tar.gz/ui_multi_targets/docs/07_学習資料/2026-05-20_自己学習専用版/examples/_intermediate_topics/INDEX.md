# 中級演習 (_intermediate_topics)

基礎を理解した方向けの中級演習です。内積からAttentionへの流れを深掘りします。

## 📚 演習順序

### 1️⃣ `内積_attention_中級.ipynb`
**所要時間**: 60-90分  
**前提知識**: 内積_初級を完了  
**目的**: 内積からAttentionへの流れを理解  
**学習内容**:
- Scaled Dot-Product Attention
- マスクの概念と実装
- 複数ヘッドの実装基礎

### 2️⃣ `中級_内積とAttention.md`
**所要時間**: 45-60分  
**目的**: Attentionの理論的背景を理解  
**学習内容**:
- Query, Key, Value の役割
- Attention重みの意味
- 実装との対応

### 3️⃣ `attention_math_demo.ipynb`
**所要時間**: 60-75分  
**目的**: Attentionの数学を可視化・実装  
**学習内容**:
- Attention計算の各ステップ
- 重みの分布の可視化
- 実装の詳細

---

## 💡 活用のコツ

1. **MD と Notebook を交互に**  
   理論を読んでから、Notebook で実装を確認します。

2. **計算を追う**  
   行列計算の中間ステップを手で追いながら進めます。

3. **図を描く**  
   Q, K, V, スコアの流れを図で理解します。

---

## 次のステップ

中級演習を完了したら、`_transformer_deep_dive`でTransformerの全体像を学びます。

---

## 🆘 困ったときはこちら

- TROUBLESHOOTING.md (reference: ../../../../TROUBLESHOOTING.md) - よくあるエラーと対応
- LEARNING_TIMELINE.md (reference: ../../../../LEARNING_TIMELINE.md) - 学習計画
