# Transformer深掘り (_transformer_deep_dive)

Attentionの仕組みを理解した方向けの演習です。Transformerアーキテクチャ全体を学びます。

## 📚 演習順序

### 1️⃣ `ffn_mlp_demo.ipynb`
**所要時間**: 45-60分  
**前提知識**: 中級演習を完了  
**目的**: Transformer内のFeed-Forward層を理解  
**学習内容**:
- MLP（多層パーセプトロン）の構造
- 活性化関数（ReLU, GELU など）
- 実装と計算

### 2️⃣ `residual_layernorm_demo.ipynb`
**所要時間**: 60-75分  
**目的**: 残差接続とLayerNormを理解  
**学習内容**:
- 残差接続（Skip Connection）の役割
- LayerNormalization の数学と効果
- Attention + FFN + 残差の組み合わせ

### 3️⃣ `positional_encoding_demo.ipynb`
**所要時間**: 45-60分  
**目的**: 位置情報の埋め込みを理解  
**学習内容**:
- なぜ位置情報が必要か
- Sinusoidal Positional Encoding
- 実装と可視化

---

## 💡 学習の流れ

```
Attention（中級）
    ↓
FFN/MLP（このセクション）
    ↓
残差接続 + LayerNorm（このセクション）
    ↓
位置エンコーディング（このセクション）
    ↓
= 完全な Transformer ブロック
```

---

## 次のステップ

Transformer深掘りを完了したら、プロジェクトの実装コードを読み始めることをお勧めします。

---

## 🆘 困ったときはこちら

- TROUBLESHOOTING.md (reference: ../../../../TROUBLESHOOTING.md) - よくあるエラーと対応
- [README.md](../../../../README.md) - 全体ガイド
