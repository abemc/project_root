# 実装演習例 (examples)

このフォルダは、学習の各段階に対応した対話的な演習（Jupyter Notebook）とユーティリティを含みます。

## 📂 フォルダ構成

### 🟦 [_basic_intro](_basic_intro/INDEX.md) - 基礎演習
初めてLLMを学ぶ方向け。内積、LLMの基礎、簡単な実装。

**時間目安**: 2-3時間

---

### 🟪 [_intermediate_topics](_intermediate_topics/INDEX.md) - 中級演習
基礎を理解した方向け。内積からAttentionへの流れ。

**時間目安**: 2.5-3.5時間

---

### 🟩 [_transformer_deep_dive](_transformer_deep_dive/INDEX.md) - Transformer深掘り
Attention以後のTransformer全体。FFN、残差接続、位置エンコーディング。

**時間目安**: 2.5-3.5時間

---

### 🟨 [_math_drills](_math_drills/INDEX.md) - 数学演習
数学的な基礎を強化。グラデーション、ベクトル、数式記号。

**時間目安**: 2-2.5時間

---

### 🟧 [_utility](_utility/INDEX.md) - ユーティリティ
学習をサポートするツール・スクリプト・図。

---

## 🎯 学習パスの選択

### 初心者向け（0～1週間）
```
1. _basic_intro を順に実行
2. _math_drills を並行学習（特に数式記号、ベクトル操作）
3. 復習：コードを修正して自分で実装する
```

### 中級者向け（1～2週間）
```
1. _intermediate_topics でAttentionを深く理解
2. _transformer_deep_dive で構成要素を学ぶ
3. 複合演習：複数のコンポーネントを組み合わせる
```

### 自分のペースで学ぶ（随時参照）
```
- 分からない数式や記号が出たら → _math_drills/数式記号_読み方ドリル.ipynb
- テンソル操作が分からなくなったら → _math_drills/vector_tensor_shapes_demo.ipynb
- 各ステップの詳細が見たいなら → 対応するNotebook を再実行
```

---

## 💡 Notebook の活用方法

1. **セルを順に実行**  
   上から下へ、セルを実行してください。

2. **出力を確認**  
   各セルの出力（数値、グラフ）が期待通りか確認します。

3. **パラメータを変更**  
   数値やハイパーパラメータを変えて、動作を観察します。

4. **コメント・メモを追記**  
   理解した内容を、Notebookにメモとして残します。

5. **再実行**  
   後日、もう一度実行して、理解が定着しているか確認します。

---

## 🔗 親フォルダへ

[2026-05-20_自己学習専用版 に戻る](../README.md)

---

**Last Updated**: 2026-05-23
