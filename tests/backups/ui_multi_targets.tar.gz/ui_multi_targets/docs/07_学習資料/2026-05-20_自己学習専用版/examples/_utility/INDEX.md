# ユーティリティ (_utility)

学習をサポートするツール・スクリプト・図です。

## 📚 ファイル一覧

### `test_llm_env.py`
**用途**: 学習環境のテスト  
**実行方法**:
```bash
python test_llm_env.py
```
**確認内容**:
- Python, NumPy, PyTorch などのバージョン
- GPU（CUDA）の利用可能性
- 必要なライブラリが正しくインストールされているか

### `flowchart LR.mmd`
**用途**: 学習フロー図（Mermaid形式）  
**用法**:
- VS Code で Mermaid プラグインで可視化
- GitHub で自動レンダリング

---

## 💡 活用シーン

- **環境構築直後**: `test_llm_env.py` を実行して、すべて正常か確認
- **学習計画の確認**: `flowchart LR.mmd` で全体フロー確認
- **トラブル時**: 出力をコピーして、質問と一緒に提供

---

## 他のセクションへ

- [基礎演習](../_basic_intro/INDEX.md)
- [中級演習](../_intermediate_topics/INDEX.md)
- [Transformer深掘り](../_transformer_deep_dive/INDEX.md)
- [数学演習](../_math_drills/INDEX.md)

---

## 🆘 困ったときはこちら

- [TROUBLESHOOTING.md](../../README.md) - よくあるエラーと対応
- [QUICK_START.md](../../README.md) - 初日ガイド
