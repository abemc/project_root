# AI数学 8週間学習計画

目的: AI/LLM 実装を数式レベルで理解する

学習時間目安: 週5〜7時間

---

## 0. 8週間の全体スケジュール（Mermaid ガント）

```mermaid
gantt
  title AI数学 8週間ロードマップ
  dateFormat  YYYY-MM-DD
  excludes    weekends

  section Foundations
  Week 1 線形代数                :w1, 2026-05-25, 7d
  Week 2 微分と連鎖律            :w2, after w1, 7d
  Week 3 確率統計                :w3, after w2, 7d
  Week 4 情報理論                :w4, after w3, 7d

  section Advanced
  Week 5 最適化                  :w5, after w4, 7d
  Week 6 行列微分                :w6, after w5, 7d
  Week 7 LLMへの接続             :crit, w7, after w6, 7d
  Week 8 総復習                  :active, w8, after w7, 7d
```

### 週ごとの成果物（表）

| 週 | 最低成果物 | 完了条件 |
|---|---|---|
| Week 1 | `Wx+b` の説明メモ1枚 | 内積と行列積を口頭説明できる |
| Week 2 | 勾配降下の説明メモ1枚 | 学習率の影響を例で説明できる |
| Week 3 | 確率の直感メモ1枚 | 条件付き確率を説明できる |
| Week 4 | CE/KL の比較メモ1枚 | CE と KL の違いを説明できる |
| Week 5 | 最適化比較メモ1枚 | SGD/Adam の違いを説明できる |
| Week 6 | 行列微分の導出ノート1枚 | MSE 勾配を導出できる |
| Week 7 | Attention/FFN/LN の要点図1枚 | Transformer 部品の役割を説明できる |
| Week 8 | 総復習サマリ1枚 | 式→コード→挙動を一貫説明できる |

---

## Week 1: 線形代数の土台
- 学習テーマ: ベクトル、行列積、ノルム、内積
- 読む: `math_primer.md` の線形代数セクション
- 実行: `examples/intro.ipynb` の前半
- 到達目標:
  - `y=Wx+b` を説明できる
  - コサイン類似度を計算できる

## Week 2: 微分と連鎖律
- 学習テーマ: 偏微分、勾配、連鎖律
- 読む: `math_primer.md` 微分セクション + `ai_math_deep_dive.md`
- 実行: `examples/grad_desc_viz.ipynb`
- 到達目標:
  - 学習率と収束の関係を説明できる
  - MSE の勾配式の意味が分かる

## Week 3: 確率統計の基礎
- 学習テーマ: 期待値、分散、条件付き確率、尤度
- 読む: `ai_math_deep_dive.md` 確率統計セクション
- 実行: `examples/llm_hands_on.ipynb`（温度を変えて挙動比較）
- 到達目標:
  - 確率出力を直感的に説明できる

## Week 4: 情報理論
- 学習テーマ: エントロピー、cross-entropy、KL、perplexity
- 読む: `ai_math_deep_dive.md` 情報理論セクション
- 実行: 自分で小さい確率分布を作り CE/KL を計算
- 到達目標:
  - CE と KL の違いを説明できる

## Week 5: 最適化
- 学習テーマ: SGD, Momentum, Adam
- 読む: `ai_math_deep_dive.md` 最適化セクション
- 実行: `grad_desc_viz.ipynb` の学習率を複数パターンで比較
- 到達目標:
  - 収束しないケースを診断できる

## Week 6: 行列微分
- 学習テーマ: 二次形式の微分、線形回帰の勾配導出
- 読む: `ai_math_deep_dive.md` 行列微分セクション
- 実行: 手計算 + Python で数値確認
- 到達目標:
  - $\nabla_\theta L=\frac{2}{N}X^T(X\theta-y)$ を導出できる

## Week 7: LLMへの接続
- 学習テーマ: トークン確率、デコーディング、perplexity
- 読む: `llm_intro.md` + `ai_math_deep_dive.md`
- 実行: `llm_hands_on.ipynb` + `examples/attention_math_demo.ipynb` + `examples/ffn_mlp_demo.ipynb` + `examples/residual_layernorm_demo.ipynb` + `examples/positional_encoding_demo.ipynb`
- 到達目標:
  - LLM の出力が確率モデルであることを説明できる
  - Self-Attention の数式を説明できる
  - FFN/MLP の式を説明できる
  - Residual / LayerNorm の安定化効果を説明できる
  - Positional Encoding の役割を説明できる

## Week 8: 総復習
- 学習テーマ: 数学→実装の往復
- 実行: 3つの notebook を再実行して解説メモを作る
- 追加: Attention と Residual/LayerNorm のノートも再実行
- 追加: `transformer_math_map.md` を見ながら全体像を1枚で復習
- 到達目標:
  - 「式→コード→挙動」を一貫して説明できる

---

## 進捗チェック（毎週）
- [ ] 今週のノートを 1 ページ書いた
- [ ] notebook を最低1つ実行した
- [ ] 分からない数式を1つ調べた
- [ ] 次週の目標を決めた
