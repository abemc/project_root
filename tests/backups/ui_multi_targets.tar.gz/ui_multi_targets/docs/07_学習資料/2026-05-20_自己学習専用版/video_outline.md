# 自己学習向けウォークスルー動画アウトライン

目的: AI 初学者が学習資料の全体像を 10〜15 分で把握し、最初の 1 週間を迷わず開始できるようにする。

## 1. 動画の想定
- 対象: AI 知識ゼロ〜初級
- 長さ: 10〜15 分
- 形式: 画面共有 + ナレーション
- 成果: 視聴後に「今日やること」を 1 つ決められる

## 2. 章立て（時間配分）
1. 導入（1 分）
- 今日のゴール
- 学習資料の置き場所

2. 学習ロードマップ全体（2 分）
- `learning_materials/00_index.md`
- `docs/07_学習資料/README.md`

3. 数学の最短ルート（3 分）
- `learning_materials/02_math/README.md`
- `docs/07_学習資料/2026-05-20_自己学習専用版/transformer_math_map.md`
- `docs/07_学習資料/2026-05-20_自己学習専用版/ai_math_deep_dive.md`

4. 実装理解の最短ルート（3 分）
- `learning_materials/04_deep_learning/README.md`
- `learning_materials/05_llm_and_rag/README.md`
- `docs/07_学習資料/2026-05-20_自己学習専用版/examples/attention_math_demo.ipynb`

5. 運用と安全（2 分）
- `learning_materials/06_mlops_and_deployment/README.md`
- `learning_materials/08_ethics_and_safety/README.md`

6. 1 週間の着手プラン（2〜4 分）
- Day 1-2: 数学基礎（線形代数 + 微分）
- Day 3-4: Attention と Transformer 数学
- Day 5-6: LLM/RAG の最小実装
- Day 7: 振り返りと次週計画

## 3. 録画時のチェックリスト
- 文字サイズは 125% 以上
- 章タイトルを必ず口頭で宣言
- 各章の最後に「次に開くファイル」を 1 つ提示
- ノートブック実行はセル 1〜2 個に限定して短く見せる
- API キーや個人情報が画面に出ないことを確認

## 4. 収録前の準備
- Python 仮想環境を有効化
- 必要ノートブックが開けることを確認
- 画面に不要な通知を出さない設定にする

## 5. 収録後の成果物
- 動画ファイル（mp4）
- このアウトラインへの実際のタイムスタンプ追記
- 視聴者向けの最初の 3 ファイル案内

## 6. 視聴者に最後に伝える一言
- 完璧に理解してから進むのではなく、まず 1 章を実行して結果を見ることを優先する。
