# 中級: 内積とAttention

対象: ベクトル/行列の基礎を終えた学習者

## 1. ゴール
- 内積を幾何学と線形代数の両面で説明できる
- scaled dot-product attention の式を shape と一緒に読める
- マスク適用時に何が変わるか説明できる

## 2. 数学的整理
内積:
$$
q \cdot k = q^T k = \sum_i q_i k_i
$$

角度との関係:
$$
q \cdot k = ||q|| ||k|| \cos\theta
$$

- 方向が近いほど内積は大きくなる
- ノルムの影響も受けるため、コサイン類似度で正規化する場合がある

## 3. Attentionでの内積
scaled dot-product attention:
$$
\mathrm{Attention}(Q, K, V) = \mathrm{softmax}\!\left(\frac{QK^T}{\sqrt{d_k}}\right)V
$$

shapeの典型:
- Q, K, V: (b, h, t, d_k)
- QK^T: (b, h, t, t)
- 出力: (b, h, t, d_k)

### なぜ \(\sqrt{d_k}\) で割るか
d_k が大きいと内積の分散が大きくなり、softmax が飽和しやすくなるため。

## 4. 表で確認

| 観点 | 内積の役割 | 実務上の意味 |
|---|---|---|
| 類似度 | q と k の整合性を数値化 | どこを見るべきかを決める |
| スケーリング | 値の過大化を抑える | 学習を安定化 |
| マスク | 不要位置のスコアを無効化 | 因果性/可変長対応 |

## 5. よくある誤解
- 「内積=角度だけ」ではない（ノルムにも依存）
- softmax 前にマスクしないと、禁止位置にも重みが乗る

## 6. ミニ演習
1. d_k=64 のとき、スケール係数を求める
2. q=(1,2,1), k=(2,1,0) の内積を計算
3. マスクあり/なしで softmax 重みがどう変わるか確認

## 7. 関連リンク
- [glossary.md](glossary.md#attention)
- [transformer_math_map.md](transformer_math_map.md)
- [examples/内積_attention_中級.ipynb](examples/内積_attention_中級.ipynb)
