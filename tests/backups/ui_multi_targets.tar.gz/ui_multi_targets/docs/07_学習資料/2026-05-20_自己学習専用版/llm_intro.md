LLM入門 — 初心者向け要点

目的
- LLM（大規模言語モデル）の概念をゼロから理解するための最短ガイド。
- 仕組み・できること・限界・安全性・実験方法を簡潔にまとめる。

1. LLMとは何か？
- LLM = Large Language Model（大規模言語モデル）。大量のテキストデータから言語の統計的な規則を学習したモデル。
- 入力（プロンプト）に応じて自然言語を生成・補完したり、要約・翻訳・質問応答などを行う。

2. 基本構成要素（直感）
- トークナイザ: 文字列を「トークン」に分割する。単語ではなく部分単位の場合が多い。
- モデル本体: トークン列を受け取り次のトークンの確率を出すニューラルネットワーク（Transformer が主流）。
- デコーディング: 確率から実際の出力を得る方法（greedy, beam, sampling, top-k/top-p）。

3. LLMの学習とファインチューニング（直感）
- 事前学習: 大量の未ラベルテキストで自己教師あり学習（次のトークン予測等）を行う。一般に計算コストが非常に高い。
- ファインチューニング: 特定タスク向けに事前学習済モデルを微調整する。データは少なくて済む場合が多い。
- 近年は「Instruction tuning」「RLHF（強化学習で人間の好みを学習）」などの手法が使われる。

4. できること・よく使われる応用
- テキスト生成（記事、メール、コード）、要約、質問応答、翻訳、対話（チャットボット）など。
- コード生成や補完（copilot など）にも強い活用例あり。

5. 限界とリスク（重要）
- 誤情報（hallucination）: 自信ありげに誤った事実を生成することがある。
- バイアス: 訓練データの偏りを反映する可能性がある。
- プライバシー: 訓練データに個人情報が含まれる場合、逸脱的に復元されるリスクがある。
- 計算やコスト: 大規模モデルは推論・学習で計算資源が必要。

6. 実験（入門ハンズオン）
- 選択肢1: Hugging Face Transformers（ローカルで小型モデルを試す）
  - インストール: `pip install transformers torch`（小型モデル推奨: distilGPT2, small GPT-2 variants）
  - サンプル:
```python
from transformers import pipeline
nlp = pipeline('text-generation', model='distilgpt2')
print(nlp('今日の天気は', max_length=30))
```
- 選択肢2: OpenAI 等の API を使う（APIキー必要、商用利用に注意）
  - サンプル（擬似）:
```python
import openai
openai.api_key = 'YOUR_KEY'
resp = openai.ChatCompletion.create(model='gpt-4o-mini', messages=[{'role':'user','content':'要約して'}])
print(resp['choices'][0]['message']['content'])
```
- Colab で試すと環境依存を避けられる。

7. プロンプト設計の基本（Prompting）
- 明確に指示する: 期待する出力形式や例を示す（few-shot）。
- 温度（temperature）を調整して創造性を制御（低いほど確定的）。
- 出力長やフォーマット制約を明示する（JSON で返すよう指示する等）。

8. セーフティと利用上のガイドライン
- 機密情報はプロンプトに含めない。
- 医療・法律等の重要領域では人間の確認を必須にする。
- 誤情報を検出する簡易チェック（事実確認、出典要求）を組み込む。

9. 学習リソース（続けるための参考）
- Hugging Face: https://huggingface.co/docs/transformers
- OpenAI docs: https://platform.openai.com/docs
- "The Illustrated Transformer"（可視化解説）
- ブログやチュートリアル（Fast.ai, DistilGPT2 紹介記事など）

10. 演習案（初心者向け）
- 演習A: `transformers` の `pipeline('text-generation')` を使って短いプロンプトを実行し、温度や max_length を変えて結果を比較する。
- 演習B: 簡単な要約タスクを few-shot prompt で試し、出力の品質を評価する。
- 演習C: 単純なプロンプト安全チェック: 応答に個人情報が含まれていないかフィルタするスクリプトを作る。

次のアクション
- この `llm_intro.md` をスライド化しますか？
- ハンズオン用の Notebook を作成して実行確認しますか？

