**ドキュメント作成計画書**

作成日: 2026-05-20
作成者: 自動生成（ペアプログラミング支援）

目的
- AI 初学者向けおよびプロジェクト内の新規参加者向けに「学習パッケージ」を作成する。
- テスト・修正の事例を教材化し、再現可能なハンズオンを提供する。

範囲（Scope）
- 対象: AI 知識ゼロ〜初級者、社内開発メンバー
- 含むもの: チートシート、数学プリマ、ハンズオン Notebook、スライド、演習問題、解答、最終配布 README
- 含まないもの: 深層理論の研究レベル解説（Bishop 等の専門書を参照）

成果物（Deliverables）
1. `learning_materials/cheatsheet-ai-basics.md` — 1ページのチートシート（完了）
2. `learning_materials/math_primer.md` — 数学プリマ（完了）
3. `learning_materials/examples/intro.ipynb` — ハンズオン Notebook（未作成）
4. `learning_materials/self-study-slides.pdf`（または PPTX）— スライド（未作成）
5. `learning_materials/exercises.md` + `learning_materials/solutions/` — 演習と解答（未作成）
6. `learning_materials/README.md` — 配布用概要と実行手順（未作成）

対象読者と想定学習時間
- 想定読者: Linux/Windows/macOS の基本操作ができる開発者、非エンジニアの技術理解者
- 想定学習時間: 約10〜12時間（分割セッション想定）

スケジュール（提案）
- Week 0 (準備): 教材テンプレ作成、Notebook テンプレ、README（1日）
- Week 1: チートシート、数学プリマ、用語集（1–2日）
- Week 2: ハンズオン Notebook と演習問題作成（2–3日）
- Week 3: スライド化とレビュー、動画作成（2日）
- Week 4: 最終レビュー、PR 作成、公開（1日）

役割分担（推奨）
- 作成者: コンテンツ制作（1人）
- レビュー: 技術レビュー（1–2人）、教育観点レビュー（1人）
- 実施: 勉強会での発表者（1人）

作成フロー（ワークフロー）
1. 各成果物のドラフトを `learning_materials/drafts/` に作成
2. コード例は `learning_materials/examples/` に配置し動作確認
3. レビューは Pull Request で行う（テンプレ: 目的・確認点・実行手順を明記）
4. レビュー完了後、`learning_materials/` 直下に移動し README を更新

品質基準（Acceptance Criteria）
- Notebook はローカルの `venv` または Google Colab で実行可能
- 演習問題に対して解答例が存在し、実行確認済み
- スライドは 10–15 枚で要点が整理されている
- README に実行手順と依存ライブラリが明記されている

レビューチェックリスト（簡易）
- [ ] 実行手順（セットアップ）が明確か
- [ ] 主要コマンドがチートシートに載っているか
- [ ] Notebook が実行可能か（依存ライブラリのバージョン明示）
- [ ] 演習に答えがあるか
- [ ] 用語集が主要キーワードをカバーしているか

リスクと軽減策
- リスク: Notebook の外部ライブラリ互換性（環境差） → 軽減策: Colab 版を用意し依存を最小化
- リスク: 受講者の前提知識の差 → 軽減策: 前提チェックリストと入門パートを用意

ファイル命名規則
- スライド: `learning_materials/self-study-slides.(pdf|pptx)`
- Notebook: `learning_materials/examples/intro.ipynb`
- チートシート/プリマ: `learning_materials/*.md`

コミュニケーションと承認
- PR を作成し、技術レビュー担当者にアサイン
- マージ前に 1 人の教育担当による内容確認

次の具体的アクション（短期）
1. `learning_materials/examples/intro.ipynb` を作成（ハンズオン: scikit-learn の分類）
2. `learning_materials/exercises.md` と `solutions/` を作成
3. `learning_materials/README.md` を作成して PR を準備

お問い合わせ先
- 作成・レビュー依頼はこのリポジトリの PR で行ってください。

---
ファイル: `learning_materials/doc_plan.md`
