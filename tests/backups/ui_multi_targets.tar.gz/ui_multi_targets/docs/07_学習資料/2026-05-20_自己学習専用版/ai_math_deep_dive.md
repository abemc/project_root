# AI数学 深掘りガイド

対象: AI/LLM を本質的に理解したい学習者  
前提: `math_primer.md` を読了済み
> 📖 **用語集**: 難しい用語は [glossary.md](glossary.md) で確認できます。
---

## 0. この資料の使い方
- まず「直感」を読む
- 次に「式」を追う
- 最後に「最小コード」を実行する

AIでは、次の8分野が特に重要です。
1. 線形代数
2. 微分積分
3. 確率統計
4. 最適化
5. 情報理論
6. 数値計算・行列微分
7. Transformer/Attention の数理
8. Residual / LayerNorm の数理

### 学習ロードマップ（概要表）

| 分野 | まず理解すること | LLMでの主な用途 |
|---|---|---|
| 線形代数 | [ベクトル](glossary.md#ベクトル)・[行列](glossary.md#行列)・[内積](glossary.md#内積) | [埋め込み](glossary.md#埋め込み)、Attention の行列演算 |
| 微分積分 | [勾配](glossary.md#勾配)、[連鎖律](glossary.md#連鎖律) | 逆伝播、重み更新 |
| 確率統計 | 条件付き確率、期待値 | 次トークン確率、不確実性 |
| 最適化 | [SGD](glossary.md#sgd)/[Adam](glossary.md#adam)、[学習率](glossary.md#学習率) | 収束速度、安定学習 |
| 情報理論 | [交差エントロピー](glossary.md#交差エントロピー)、[KL](glossary.md#klダイバージェンス)、[パープレキシティ](glossary.md#パープレキシティ) | 訓練目的、評価指標 |
| 行列微分 | MSE の勾配など | 理論と実装の接続 |
| Attention 数理 | [Q/K/V](glossary.md#qkv)、[softmax](glossary.md#ソフトマックス) | 文脈選択の中核 |
| Residual/LayerNorm | 安定化の仕組み | [深い層の学習安定化](glossary.md#residual-connection) |

---

## 1. 線形代数（最重要）

### 1-1. なぜ重要か
- ニューラルネットの基本演算は `Wx + b`
- Attention は行列積と softmax の組み合わせ
- 埋め込み空間の類似度は内積・コサイン類似度

### 1-2. 最低限の概念
- ベクトル、行列、転置、逆行列
- 固有値・固有ベクトル（安定性・圧縮で重要）
- SVD（次元圧縮・ノイズ除去）

### 1-3. 重要公式
- 内積: $x^T y$
- ノルム: $||x||_2 = \sqrt{x^T x}$
- 線形変換: $y = Wx + b$
- コサイン類似度: $\cos(\theta)=\frac{x^Ty}{||x||\,||y||}$

---

## 2. 微分積分（勾配・逆伝播）

### 2-1. なぜ重要か
- 学習は損失関数を最小化する問題
- 更新式は勾配に依存

### 2-2. 最低限の概念
- 偏微分、勾配、ヤコビアン
- 連鎖律（backprop の核心）

### 2-3. 重要公式
- 勾配降下: $\theta_{t+1}=\theta_t-\eta\nabla_\theta L(\theta_t)$
- 連鎖律: $\frac{\partial z}{\partial x}=\frac{\partial z}{\partial y}\frac{\partial y}{\partial x}$

### 2-4. よく使う導関数
- $\frac{d}{dx}x^2=2x$
- sigmoid: $\sigma'(x)=\sigma(x)(1-\sigma(x))$
- softmax + cross-entropy の組み合わせは勾配が簡潔になる

---

## 3. 確率統計（不確実性の理解）

### 3-1. なぜ重要か
- モデル出力は確率分布
- 予測は期待値・尤度で評価

### 3-2. 最低限の概念
- 条件付き確率、ベイズの定理
- 尤度、対数尤度
- 期待値、分散、共分散

### 3-3. 重要公式
- ベイズ: $P(A|B)=\frac{P(B|A)P(A)}{P(B)}$
- 期待値: $E[X]=\sum_x xP(x)$（離散）
- 分散: $Var(X)=E[(X-E[X])^2]$

---

## 4. 最適化（学習を進める技術）

### 4-1. なぜ重要か
- 同じモデルでも最適化が悪いと学習が進まない

### 4-2. 重要テーマ
- SGD / Momentum / Adam
- 学習率スケジューラ
- 勾配消失・爆発と対策（正規化、初期化）

### 4-3. 実務での見るポイント
- train loss と val loss の乖離
- 学習率変更時の収束速度
- 勾配ノルムの監視

---

## 5. 情報理論（LLMで頻出）

### 5-1. なぜ重要か
- cross-entropy、perplexity は LLM 評価の中心

### 5-2. 重要公式
- エントロピー: $H(P)=-\sum_x P(x)\log P(x)$
- 交差エントロピー: $H(P,Q)=-\sum_x P(x)\log Q(x)$
- KLダイバージェンス: $D_{KL}(P||Q)=\sum_x P(x)\log\frac{P(x)}{Q(x)}$
- perplexity: $\exp(\text{平均NLL})$

### 5-3. 直感
- KL は「真の分布 P を、モデル分布 Q で近似したときの情報損失」

---

## 6. 行列微分（中級→上級の壁）

### 6-1. 目的
- 実装と理論をつなぐ

### 6-2. よく使う結果
- $\frac{\partial}{\partial x}(a^Tx)=a$
- $\frac{\partial}{\partial x}(x^TAx)=(A+A^T)x$
- MSE の勾配（線形回帰）:
  $$L=\frac{1}{N}||X\theta-y||^2 \Rightarrow \nabla_\theta L=\frac{2}{N}X^T(X\theta-y)$$

---

## 7. Transformer/Attention の数理（LLMの中核）

### 7-1. Self-Attention の基本式

入力を $X \in \mathbb{R}^{n \times d}$ とすると、

$$Q=XW_Q, \quad K=XW_K, \quad V=XW_V$$

Attention 出力は

$$\text{Attention}(Q,K,V)=\text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$$

### 7-1.5 Attention 計算フロー（Mermaid 図）

```mermaid
flowchart LR
  X["Input X (n,d)"] --> WQ["W_Q"]
  X --> WK["W_K"]
  X --> WV["W_V"]
  WQ --> Q["Q (n,d_k)"]
  WK --> K["K (n,d_k)"]
  WV --> V["V (n,d_v)"]
  Q --> S["QK^T / sqrt(d_k)"]
  K --> S
  S --> P["softmax"]
  P --> O["P @ V"]
  V --> O
  O --> Y["Attention output (n,d_v)"]
```

### 7-2. なぜ $1/\sqrt{d_k}$ で割るのか
- $d_k$ が大きいと内積の分散が大きくなり、softmax が飽和しやすくなる
- スケーリングでスコアの振れ幅を抑え、学習を安定化する

### 7-3. Multi-Head Attention

複数ヘッドで異なる注目パターンを学習し、最後に結合する:

$$\text{MHA}(X)=\text{Concat}(head_1,\dots,head_h)W_O$$

各ヘッドは独立に $W_Q, W_K, W_V$ を持つ。

### 7-4. 位置情報（Positional Encoding）
- Self-Attention 単体は順序情報を持たないため、位置情報を別途与える
- 学習型位置埋め込み: 位置ごとに学習可能なベクトルを持つ
- 正弦波位置埋め込み: 位置 $p$ と次元 $i$ に対し、

$$PE_{(p,2i)}=\sin\left(p/10000^{2i/d_{model}}\right)$$

$$PE_{(p,2i+1)}=\cos\left(p/10000^{2i/d_{model}}\right)$$

- 低次元は短い周期、高次元は長い周期を持つため、相対位置が表現しやすい

### 7-5. 最小実験
- `examples/attention_math_demo.ipynb` で $QK^T$、softmax 重み、最終出力を確認
- `examples/positional_encoding_demo.ipynb` で正弦波位置埋め込みを可視化

---

## 8. Residual / LayerNorm の数理（Transformer安定化の要）

### 8-0. Feed-Forward Network / MLP
- Transformer ブロック内の各トークンに独立に適用される2層の全結合ネットワーク
- 基本形:

$$\text{FFN}(x)=W_2\,\phi(W_1x+b_1)+b_2$$

- ここで $\phi$ は ReLU や GELU などの非線形関数
- Attention が「どこを見るか」を決めるのに対し、FFN は「各位置の表現をどう変換するか」を担う
- 実装では hidden 次元を一時的に大きくしてから元に戻すことが多い

### 8-1. なぜ重要か
- 非線形変換により表現力を増やす
- 各トークンの特徴を独立に再構成する
- Attention と組み合わせることで、文脈の収集と表現変換を分担できる

### 8-2. 最小実験
- `examples/ffn_mlp_demo.ipynb` で線形→非線形→線形の流れを確認

---

### 8-3. Residual Connection
- 基本形: $y = x + F(x)$
- 直感: 入力をそのまま足し戻すことで、深い層でも情報と勾配が伝わりやすくなる
- Transformer では Attention や MLP の後に Residual を入れる

### 8-4. LayerNorm

各サンプルの最後の次元方向に対して平均と分散を取り、正規化する:

$$\mu = \frac{1}{d}\sum_{i=1}^{d}x_i,\quad \sigma^2 = \frac{1}{d}\sum_{i=1}^{d}(x_i-\mu)^2$$

$$\text{LayerNorm}(x)=\gamma\frac{x-\mu}{\sqrt{\sigma^2+\epsilon}}+\beta$$

- $\gamma, \beta$ は学習可能なスケール/シフト
- バッチ全体ではなく、サンプル単位で安定化するのが特徴

### 8-5. なぜ効くのか
- Residual により勾配消失を緩和しやすい
- LayerNorm により内部表現のスケールが崩れにくい
- Transformer ではこの2つが学習安定性の土台になる

### 8-6. 最小実験
- `examples/residual_layernorm_demo.ipynb` で数値を確認

### 8-7. Transformer ブロック全体（Mermaid 図）

```mermaid
flowchart TD
  IN["Input"] --> MHA["Multi-Head Attention"]
  MHA --> ADD1["Add (Residual)"]
  IN --> ADD1
  ADD1 --> LN1["LayerNorm"]
  LN1 --> FFN["FFN / MLP"]
  FFN --> ADD2["Add (Residual)"]
  LN1 --> ADD2
  ADD2 --> LN2["LayerNorm"]
  LN2 --> OUT["Output"]
```

---

## 9. AIでの接続マップ
- 線形代数 → 埋め込み、Attention、主成分
- 微分積分 → 逆伝播、最適化
- 確率統計 → 不確実性、生成確率、評価
- 情報理論 → cross-entropy、perplexity
- 数値計算 → 学習安定性、計算誤差対策
- Attention数理 → LLM の文脈理解・長距離依存の学習
- Residual/LayerNorm → 深いTransformerの学習安定化

### 接続マップ（表）

| 数学概念 | 直接つながる実装 | どこで確認するか |
|---|---|---|
| 行列積 | `QK^T`, `XW+b` | `examples/attention_math_demo.ipynb` |
| softmax | 注意重みの確率化 | `examples/attention_math_demo.ipynb` |
| 勾配降下 | パラメータ更新 | `examples/grad_desc_viz.ipynb` |
| LayerNorm | スケール安定化 | `examples/residual_layernorm_demo.ipynb` |
| FFN/MLP | 各トークンの非線形変換 | `examples/ffn_mlp_demo.ipynb` |

---

## 10. 推奨学習順（深掘り）
1. 線形代数（行列積・固有値・SVD）
2. 微分積分（偏微分・連鎖律）
3. 確率統計（条件付き確率・尤度）
4. 最適化（SGD/Adam の挙動差）
5. 情報理論（CE/KL/perplexity）
6. 行列微分（実装式に接続）
7. Attention数理（QKV, softmax, multi-head）
8. Residual/LayerNorm（安定化）

---

## 11. 最小実験（このリポジトリ内）
- 勾配の可視化: `examples/grad_desc_viz.ipynb`
- 分類の基礎: `examples/intro.ipynb`
- LLMの挙動: `examples/llm_hands_on.ipynb`
- Attention数理: `examples/attention_math_demo.ipynb`
- Residual/LayerNorm: `examples/residual_layernorm_demo.ipynb`

---

## 12. 到達目標（チェック）
- [ ] `Wx+b` を図と式で説明できる
- [ ] 勾配降下と学習率の関係を説明できる
- [ ] cross-entropy と KL の違いを説明できる
- [ ] perplexity の意味を説明できる
- [ ] MSE 勾配式を自力で導出できる
- [ ] Self-Attention の式を成分ごとに説明できる
- [ ] Residual と LayerNorm の役割を説明できる

---

## 13. よくあるつまずき
- `Q`, `K`, `V` の違いが曖昧になる
  - `Q` は「何を探すか」、`K` は「何を持っているか」、`V` は「実際に取り出す情報」
- `softmax(QK^T / sqrt(d_k))` の意味が見えない
  - 行列の各行ごとに「どの位置に注目するか」の確率分布を作っている
- FFN と Attention の役割が混ざる
  - Attention は「参照先の選択」、FFN は「各位置の変換」
- Residual の意味が感覚的に掴みにくい
  - 入力を足し戻すことで情報の通り道を残す
- LayerNorm と BatchNorm の違いが曖昧になる
  - LayerNorm はサンプル単位、BatchNorm はバッチ単位で正規化する
- Positional Encoding の必要性を忘れやすい
  - Self-Attention 単体では順序が分からないため、語順情報を別途与える
