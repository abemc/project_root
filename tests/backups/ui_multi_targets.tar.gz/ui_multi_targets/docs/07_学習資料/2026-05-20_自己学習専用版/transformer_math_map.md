# Transformer 数学マップ

目的: Attention, FFN/MLP, Residual/LayerNorm, Positional Encoding の関係を 1 枚で把握する。

> 📖 **用語集**: わからない用語は [glossary.md](glossary.md) を参照してください。

---

## 1. 全体像

Transformer ブロックの中では、次の流れが繰り返されます。

```mermaid
flowchart TD
    X["入力 X"] --> PE["Positional Encoding"]
    PE --> SA["Self-Attention"]
    SA --> ADD1["Residual + LayerNorm"]
    ADD1 --> FFN["FFN / MLP"]
    FFN --> ADD2["Residual + LayerNorm"]
    ADD2 --> Y["出力"]
```

### ブロックごとの入出力 shape（表）

| ブロック | 入力 shape | 出力 shape | 主な役割 |
|---|---|---|---|
| Positional Encoding | `(b, t, d_model)` | `(b, t, d_model)` | 順序情報を付与 |
| Self-Attention | `(b, t, d_model)` | `(b, t, d_model)` | 文脈参照先を重み付け |
| Residual + LayerNorm | `(b, t, d_model)` | `(b, t, d_model)` | 情報維持と安定化 |
| FFN / MLP | `(b, t, d_model)` | `(b, t, d_model)` | 各位置の非線形変換 |

---

## 2. 役割の整理

### [Positional Encoding](glossary.md#positional-encoding)
- 単語の順番をベクトルに埋め込む
- Self-Attention は順序を自動では持たないため、先に与える必要がある

### [Self-Attention](glossary.md#attention)
- 文中のどの位置を参照するかを決める
- 式: `softmax(QK^T / sqrt(d_k)) V`
- 長距離依存を捧えやすい

### [FFN / MLP](glossary.md#ffn--mlp)
- 各トークンに独立な非線形変換を行う
- 式: `W2 φ(W1x + b1) + b2`
- 表現を「変換」する担当

### [Residual Connection](glossary.md#residual-connection)
- `x + F(x)` の形で元の情報を保持する
- 勾配を流しやすくする

### [LayerNorm](glossary.md#layernorm)
- 各トークンの内部表現を安定化する
- 学習のスケールを揃える

---

## 3. 数学の対応表

| 要素 | 数式 | 直感 |
|---|---|---|
| [Positional Encoding](glossary.md#positional-encoding) | `PE(p, 2i), PE(p, 2i+1)` | 位置の埋め込み |
| [Self-Attention](glossary.md#attention) | `softmax(QK^T / sqrt(d_k)) V` | 参照先の重み付け |
| [FFN / MLP](glossary.md#ffn--mlp) | `W2 φ(W1x + b1) + b2` | 各位置の再変換 |
| [Residual](glossary.md#residual-connection) | `x + F(x)` | 情報と勾配の通り道 |
| [LayerNorm](glossary.md#layernorm) | `γ (x-μ)/sqrt(σ^2+ε) + β` | スケール安定化 |

### Attention 内部の shape 変化（Mermaid 図）

```mermaid
flowchart LR
  X["X (b,t,d_model)"] --> QKV["Linear projections"]
  QKV --> Q["Q (b,h,t,d_k)"]
  QKV --> K["K (b,h,t,d_k)"]
  QKV --> V["V (b,h,t,d_k)"]
  Q --> S["QK^T / sqrt(d_k)"]
  K --> S
  S --> P["softmax"]
  P --> O["weights @ V"]
  V --> O
  O --> C["Concat + W_O"]
  C --> Y["(b,t,d_model)"]
```

---

## 4. 学習順
1. `math_primer.md` で基礎を復習する
2. `ai_math_deep_dive.md` で数式を追う
3. `attention_math_demo.ipynb` で重みを見る
4. `ffn_mlp_demo.ipynb` で変換を確認する
5. `residual_layernorm_demo.ipynb` で安定化を確認する
6. `positional_encoding_demo.ipynb` で位置表現を確認する

---

## 5. このマップの使い方
- まず全体の流れを 1 回読む
- 次に各項目の式を見て、ノートブックで確認する
- 迷ったら「今はどの部品を理解しているか」をこのマップで位置づける

---

## 6. 関連資料
- [README](README.md)
- [AI数学 深掘りガイド](ai_math_deep_dive.md)
- [8週間学習計画](ai_math_study_plan_8weeks.md)
- [Attention デモ](examples/_intermediate_topics/attention_math_demo.ipynb)
- [FFN/MLP デモ](examples/_transformer_deep_dive/ffn_mlp_demo.ipynb)
- [Residual/LayerNorm デモ](examples/residual_layernorm_demo.ipynb)
- [Positional Encoding デモ](examples/positional_encoding_demo.ipynb)
