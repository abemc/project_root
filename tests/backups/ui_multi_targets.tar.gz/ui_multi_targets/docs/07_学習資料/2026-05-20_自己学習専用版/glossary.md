# 用語集 — AI 初心者向け

このファイルの各用語には Markdown アンカーが付いています。  
他のドキュメントから `[用語](glossary.md#アンカー)` の形でリンクできます。

---

## カテゴリ別インデックス

| カテゴリ | 用語（リンク） |
|---|---|
| 線形代数 | [ベクトル](#ベクトル) · [行列](#行列) · [テンソル](#テンソル) · [内積](#内積) · [行列積](#行列積) · [転置](#転置) · [shape](#shape) |
| 微分・最適化 | [勾配](#勾配) · [連鎖律](#連鎖律) · [勾配降下法](#勾配降下法) · [学習率](#学習率) · [SGD](#sgd) · [Adam](#adam) |
| 損失・評価 | [損失関数](#損失関数) · [MSE](#mse) · [交差エントロピー](#交差エントロピー) · [パープレキシティ](#パープレキシティ) · [KLダイバージェンス](#klダイバージェンス) |
| NN・活性化 | [活性化関数](#活性化関数) · [ReLU](#relu) · [GELU](#gelu) · [ソフトマックス](#ソフトマックス) · [ドロップアウト](#ドロップアウト) |
| Transformer | [埋め込み](#埋め込み) · [トークン](#トークン) · [Attention](#attention) · [Q/K/V](#qkv) · [Multi-Head Attention](#multi-head-attention) · [因果マスク](#因果マスク) · [Padding マスク](#padding-マスク) |
| Transformer部品 | [Positional Encoding](#positional-encoding) · [FFN / MLP](#ffn--mlp) · [Residual Connection](#residual-connection) · [LayerNorm](#layernorm) |
| LLM・RAG | [LLM](#llm) · [RAG](#rag) · [プロンプト](#プロンプト) · [コンテキスト窓](#コンテキスト窓) · [デコーディング](#デコーディング) |
| 一般 | [バッチ](#バッチ) · [エポック](#エポック) · [過学習](#過学習) · [正則化](#正則化) · [推論](#推論) |

---

## 線形代数

### ベクトル
数を1次元に並べた列。AI では「単語の意味」や「文の特徴」を数列で表す。  
`shape: (d,)`  
→ 参照: [vector_tensor_basics.md](vector_tensor_basics.md#1-まず結論)

### 行列
数を2次元の格子状に並べたもの。重み行列や入力バッチの表現に使う。  
`shape: (n, d)`  
→ 参照: [vector_tensor_basics.md](vector_tensor_basics.md#shape-対応表)

### テンソル
3次元以上の多次元配列。バッチ・系列・次元をまとめて扱う。  
`shape: (b, t, d)` など  
→ 参照: [vector_tensor_basics.md](vector_tensor_basics.md#1-まず結論)

### 内積
2つのベクトルの要素ごとの積の総和。類似度の計算に使う。  
$x \cdot y = \sum_i x_i y_i$  
→ 参照: [ai_math_deep_dive.md](ai_math_deep_dive.md#1-3-重要公式)

### 行列積
行列同士の積。線形変換（重みの適用）の基本演算。  
内側の次元が一致している必要がある: `(m, k) @ (k, n) → (m, n)`  
→ 参照: [vector_tensor_basics.md](vector_tensor_basics.md#3-ai-でよく使う演算)

### 転置
行と列を入れ替える操作。`A.T` で実装。Attention の `K^T` に登場する。

### shape
テンソルの各次元のサイズをまとめたタプル。  
`(b, t, d)` なら「バッチ b 個、トークン t 個、次元 d」  
→ 参照: [vector_tensor_basics.md](vector_tensor_basics.md#2-形shapeだけ先に覚える)

---

## 微分・最適化

### 勾配
多変数関数の各変数に対する偏微分をまとめたベクトル。損失を最も増やす方向を指す。  
→ 参照: [ai_math_deep_dive.md](ai_math_deep_dive.md#2-微분적분勾配逆伝播)

### 連鎖律
合成関数の微分を求めるルール。逆伝播（Backprop）の理論的根拠。  
$\frac{\partial z}{\partial x} = \frac{\partial z}{\partial y} \cdot \frac{\partial y}{\partial x}$

### 勾配降下法
損失関数を小さくするため、勾配の逆方向にパラメータを更新する最適化手法。  
$\theta \leftarrow \theta - \eta \nabla_\theta L$  
→ 参照: [examples/grad_desc_viz.ipynb](examples/grad_desc_viz.ipynb)

### 学習率
勾配降下での更新ステップの大きさ（$\eta$）。大きすぎると発散、小さすぎると収束が遅い。

### SGD
確率的勾配降下法。ミニバッチ単位でパラメータを更新する最も基本的な最適化器。

### Adam
Momentum と RMSprop を組み合わせた適応的学習率の最適化器。実務で広く使われる。

---

## 損失・評価

### 損失関数
モデル出力と正解の「食い違い」を数値化する関数。学習はこの値を最小化する。

### MSE
平均二乗誤差。回帰問題の代表的な損失関数。  
$L = \frac{1}{N} \sum_i (y_i - \hat{y}_i)^2$

### 交差エントロピー
分類問題・LLM 訓練の代表的な損失関数。  
$H(P, Q) = -\sum_x P(x) \log Q(x)$  
→ 参照: [ai_math_deep_dive.md](ai_math_deep_dive.md#5-情報理論lllmで頻出)

### パープレキシティ
言語モデルの評価指標。低いほど良い。  
$PPL = \exp(\text{平均 NLL})$

### KLダイバージェンス
2つの確率分布の差を測る指標。  
$D_{KL}(P \| Q) = \sum_x P(x) \log \frac{P(x)}{Q(x)}$

---

## NN・活性化

### 活性化関数
ニューラルネットに非線形性を与える関数。線形変換だけでは多層化の意味がない。

### ReLU
$\text{ReLU}(x) = \max(0, x)$。負を0にカットする最もシンプルな活性化関数。

### GELU
$\text{GELU}(x) \approx x \cdot \sigma(1.702x)$。GPT 系 LLM で広く使われる滑らかな活性化関数。

### ソフトマックス
ベクトルの各要素を確率に変換する関数（合計が1になる）。Attention のスコア正規化に必須。  
$\text{softmax}(x_i) = \frac{e^{x_i}}{\sum_j e^{x_j}}$  
→ 参照: [transformer_math_map.md](transformer_math_map.md#3-数学の対応表)

### ドロップアウト
学習時にランダムにニューロンを0にする正則化手法。過学習を抑える。

---

## Transformer

### 埋め込み
単語・トークンを固定次元のベクトルに変換すること。  
`shape: (vocab_size, d_model)`  
→ 参照: [llm_intro.md](llm_intro.md)

### トークン
テキストをモデルが扱う最小単位（単語・部分文字列など）に分割したもの。

### Attention
系列内のどのトークンに注目するかを学習する機構。Q/K/V の内積からスコアを計算する。  
$\text{Attention}(Q,K,V) = \text{softmax}\!\left(\frac{QK^T}{\sqrt{d_k}}\right) V$  
→ 参照: [transformer_math_map.md](transformer_math_map.md#3-数学の対応表) · [examples/attention_math_demo.ipynb](examples/_intermediate_topics/attention_math_demo.ipynb)

### Q/K/V
Attention で使うクエリ（Q）・キー（K）・バリュー（V）の3つの行列。  
- Q: 「何を探すか」  
- K: 「何を持っているか」  
- V: 「実際に取り出す情報」  
`shape: (b, h, t, d_k)`  
→ 参照: [vector_tensor_basics.md](vector_tensor_basics.md#5-attention-でのテンソルの見方) · [examples/vector_tensor_shapes_demo.ipynb](examples/vector_tensor_shapes_demo.ipynb)

### Multi-Head Attention
複数の Attention ヘッドを並列に実行し、異なる注目パターンを学習する仕組み。  
出力を結合して線形変換する。

### 因果マスク
デコーダで未来トークンを見えないようにする上三角マスク。  
→ 参照: [examples/vector_tensor_shapes_demo.ipynb](examples/vector_tensor_shapes_demo.ipynb)

### Padding マスク
バッチ内で系列長が異なる場合に、パディング位置を無効化するマスク。  
→ 参照: [examples/vector_tensor_shapes_demo.ipynb](examples/vector_tensor_shapes_demo.ipynb)

---

## Transformer 部品

### Positional Encoding
Self-Attention が順序を持たないため、位置情報を入力に付与する仕組み。  
$PE_{(p,2i)} = \sin(p / 10000^{2i/d})$  
→ 参照: [examples/positional_encoding_demo.ipynb](examples/positional_encoding_demo.ipynb)

### FFN / MLP
Transformer ブロック内で各トークンに独立に適用される2層全結合ネットワーク。  
$\text{FFN}(x) = W_2\,\phi(W_1 x + b_1) + b_2$  
→ 参照: [examples/ffn_mlp_demo.ipynb](examples/_transformer_deep_dive/ffn_mlp_demo.ipynb)

### Residual Connection
入力をそのまま出力に加算する接続。`y = x + F(x)`  
勾配消失を防ぎ、深い層でも学習を可能にする。  
→ 参照: [ai_math_deep_dive.md](ai_math_deep_dive.md#8-3-residual-connection) · [examples/residual_layernorm_demo.ipynb](examples/residual_layernorm_demo.ipynb)

### LayerNorm
各サンプルの特徴方向の平均・分散で正規化し、スケールを安定させる手法。  
$\text{LN}(x) = \gamma \frac{x - \mu}{\sqrt{\sigma^2 + \epsilon}} + \beta$  
→ 参照: [ai_math_deep_dive.md](ai_math_deep_dive.md#8-4-layernorm) · [examples/residual_layernorm_demo.ipynb](examples/residual_layernorm_demo.ipynb)

---

## LLM・RAG

### LLM
Large Language Model。大規模テキストで事前学習された言語モデル（例: GPT, LLaMA）。  
→ 参照: [llm_intro.md](llm_intro.md)

### RAG
Retrieval-Augmented Generation。外部知識を検索してからLLMで生成する手法。

### プロンプト
LLM への入力テキスト。指示・文脈・質問などを含む。

### コンテキスト窓
LLM が一度に参照できるトークン数の上限。

### デコーディング
確率分布から次トークンを選ぶ方法。greedy / top-k / top-p / temperature サンプリングなど。

---

## 一般

### バッチ
一度の更新で使うデータのまとまり。`shape` の `b` 軸に対応。

### エポック
全訓練データを1周した学習の単位。

### 過学習
訓練データに過度に適合し、未知データで性能が落ちる現象。  
→ 参照: [math_primer.md](math_primer.md)

### 正則化
過学習を抑える手法の総称（L2、Dropout など）。

### 推論
学習済みモデルを使って新しいデータに予測を行うこと。

