# 上級_Mamba（選択的状態空間モデル）入門

Mambaは、2023年後半に Albert Gu と Tri Dao によって提案された、**状態空間モデル（State Space Model: SSM）**に基づく新しいディープラーニングアーキテクチャです。 

Transformerの「入力シーケンス長 $L$ の二乗（$O(L^2)$）で計算量が増える」という弱点を克服し、**線形時間（$O(L)$）の計算量**で超長文を高速かつ高精度に処理できるため、ポストTransformerの筆頭候補として注目されています。

---

## 1. Mambaの3大革新要素

Mambaがこれまでの時系列モデル（RNNや従来のS4などの状態空間モデル）と決定的に異なる点は、以下の3点です。

1. **選択メカニズム（Selection Mechanism）**
   - 従来のSSMは「入力に関わらず状態の遷移ルール（行列 $A, B, C$）が常に一定」という時系列普遍（LTI）モデルでした。
   - Mambaは、パラメータ $B, C, \Delta$ を**入力データ $x_t$ に応じて動的に変化させる（選択的）**ように設計し、Transformerと同様の文脈依存の高度な推論を可能にしました。
2. **離散化（Discretization）のパラメータ化**
   - 連続時間の方程式をデジタルコンピュータで扱うための「離散化」のステップ幅 $\Delta$ を入力依存にし、重要な情報をどれだけ引き伸ばして（あるいは短く）記憶するかをモデル自身が制御できるようにしました。
3. **ハードウェア指向の並列スキャン（Hardware-Aware Parallel Scan）**
   - 動的パラメータ化によって、従来のSSMで高速化に使われていた「畳み込み（FFT）による一括計算」が使えなくなりました。
   - Mambaは、GPUの高速なSRAMと遅いHBM（グローバルメモリ）間のデータ転送を最小限に抑える**カスタムCUDA/Tritonカーネル**を書き、逐次的なスキャン処理をハードウェアレベルで並列化・超高速化しました。

---

## 2. 状態空間モデル（SSM）の基本と数学的背景

### 2.1 連続時間表現

SSMは、制御工学における線形動的システムにインスパイアされています。入力 $x(t)$ から隠れ状態 $h(t)$ を経て、出力 $y(t)$ を得る連続時間方程式は以下のように記述されます。

$$h'(t) = A h(t) + B x(t)$$
$$y(t) = C h(t)$$

- $h(t) \in \mathbb{R}^N$: 隠れ状態（潜在状態ベクトル、次元 $N$）
- $x(t) \in \mathbb{R}$: 時刻 $t$ における入力トークン（またはチャネル値）
- $y(t) \in \mathbb{R}$: 時刻 $t$ における出力値
- $A \in \mathbb{R}^{N \times N}$: 状態遷移マトリクス（過去の状態をどう減衰・変化させるか）
- $B \in \mathbb{R}^{N \times 1}$: 入力マトリクス（入力をどう隠れ状態に取り込むか）
- $C \in \mathbb{R}^{1 \times N}$: 出力マトリクス（隠れ状態からどう出力を取り出すか）

---

### 2.2 離散化（Discretization）

コンピュータで扱うために、連続時間モデルをサンプリング周期（時間刻み幅） $\Delta$ を用いて離散化します。Mambaでは一般に **Zero-Order Hold (ZOH)** 離散化法を使用します。

$$\bar{A} = \exp(\Delta A)$$
$$\bar{B} = (\Delta A)^{-1} (\exp(\Delta A) - I) \cdot \Delta B$$

数式を簡略化（一次近似など）すると、以下のように実装できます：

$$\bar{A} \approx \exp(\Delta A)$$
$$\bar{B} \approx \Delta B$$

この離散化されたパラメータ $\bar{A}, \bar{B}$ を用いて、離散時間のリカレント推論（スキャン）を行います。

$$h_t = \bar{A} h_{t-1} + \bar{B} x_t$$
$$y_t = C h_t$$

> **学習用コードとのマッピング:**
> [model.py](file:///home/abemc/project_root/src/model.py) の `selective_ssm` 関数内の以下のループ処理が、この数学的な更新式に直接対応しています。
> ```python
> # 離散化
> A_bar = torch.exp(dt_step.unsqueeze(-1) * A.unsqueeze(0)) # exp(Δ * A)
> B_bar = dt_step.unsqueeze(-1) * B_step.unsqueeze(1)        # Δ * B
> # 状態更新
> h = A_bar * h + B_bar * u_step.unsqueeze(-1)              # h_t = A_bar * h_t-1 + B_bar * x_t
> # 出力
> y_step = torch.einsum("bdn,bn->bd", h, C_step)             # y_t = C @ h_t
> ```

---

## 3. 選択メカニズム（Selection Mechanism）の詳細

従来のS4などの状態空間モデルは、シーケンス全体で $\Delta, B, C$ が固定（定数）でした。これは「入力に関係なく常に同じ減衰率と取り込み率で情報を処理する」ことを意味します。この制約（LTI: 線形時間不変）により、**「特定のキーワードだけを強く記憶する」「不要な単語をスキップする」**といった複雑な注意（Attention）のような動作ができませんでした。

Mambaは、これらを**入力 $x_t$ の線形射影**とすることで、各時間ステップで動的に決定します。

$$B_t = \text{Linear}_B(x_t)$$
$$C_t = \text{Linear}_C(x_t)$$
$$\Delta_t = \text{Softplus}(\text{Linear}_{\Delta}(x_t))$$

- **$\Delta_t$ の動的変化:** $\Delta_t$（時間刻み）が大きくなると、モデルは現在の入力 $x_t$ に集中し、過去の状態を急速に忘却します。逆に $\Delta_t$ が小さいとき、過去の状態を長く保持します。これは、不要な単語（接続詞など）を無視し、重要な単語を長期間記憶する「ゲート機能」として働きます。
- **$B_t, C_t$ の動的変化:** 入力トークンに応じて、どの情報を状態ベクトル $h_t$ のどの次元に書き込み、あるいは読み出すかを選択的に制御します。

---

## 4. Mambaブロックのアーキテクチャ

MambaBlockは、HuggingFace等で一般的に提供されている形式を含め、以下のようなフローで入力を処理します。

```mermaid
graph TD
    Input["入力 x (B, T, D_model)"] --> Split{"分岐 (in_proj)"}
    
    %% SSM Branch
    Split -->|"SSMブランチ"| LinearSSM["Linear (SSM用射影: D_inner)"]
    LinearSSM --> Conv1d["Conv1d (局所特徴の畳み込み)"]
    Conv1d --> SiLU1["SiLU (活性化)"]
    
    %% Selective SSM inputs
    SiLU1 --> ProjParams["パラメータ射影 (x_proj / dt_proj)"]
    ProjParams -->|"B, C, dt"| SelectiveSSM["Selective SSM (選択的状態スキャン)"]
    SiLU1 -->|"入力 u"| SelectiveSSM
    
    %% Gate Branch
    Split -->|"ゲートブランチ"| LinearGate["Linear (ゲート用射影: D_inner)"]
    LinearGate --> SiLU2["SiLU (ゲートの活性化)"]
    
    %% Output Merge
    SelectiveSSM --> Mul["要素積 (*)"]
    SiLU2 --> Mul
    
    Mul --> OutProj["Linear (出力射影: D_model)"]
    OutProj --> Output["最終出力 (B, T, D_model)"]

    style Input fill:#e8f4ff,stroke:#3b82f6,stroke-width:2px;
    style Output fill:#e8f4ff,stroke:#3b82f6,stroke-width:2px;
    style SelectiveSSM fill:#fef3c7,stroke:#d97706,stroke-width:2px;
    style Split fill:#f3f4f6,stroke:#9ca3af;
    style Mul fill:#f3f4f6,stroke:#9ca3af;
```

1. **次元拡張（`in_proj`）:**
   - 入力を `d_inner = expand * d_model`（通常は2倍）に拡張し、SSMブランチと残差ゲートブランチに分割します。
2. **局所統合（`Conv1d`）:**
   - SSMブランチでは、時間軸方向にカーネルサイズ4などの軽い1D畳み込みを行い、局所的なトークン同士のつながり（n-gram的特徴）を補足します。
3. **選択的状態空間スキャン（`selective_ssm`）:**
   - 前述 of 入力依存パラメータ $B, C, \Delta$ を計算し、状態スキャンを行います。
4. **乗算型ゲート（Gated Connection）:**
   - スキャン後の出力 $y$ に対し、もう一方のブランチから取得し活性化した `res` ベクトルを掛け合わせることで、情報をフィルタリングします。
5. **出力射影（`out_proj`）:**
   - 内部チャネル `d_inner` から元のモデル次元 `d_model` に戻し、残差接続へと合流します。

---

## 5. Transformer（GPT）との詳細比較

| 項目 | Transformer (GPT) | Mamba |
| :--- | :--- | :--- |
| **主要メカニズム** | 自身対比アテンション (Self-Attention) | 選択的状態空間スキャン (Selective SSM Scan) |
| **シーケンス長 $L$ の計算量** | **二乗時間 ($O(L^2)$)** | **線形時間 ($O(L)$)** |
| **推論時のメモリ消費** | **$O(L)$ (KVキャッシュが成長し続ける)** | **$O(1)$ (固定サイズの状態 $h$ のみ保持)** |
| **文脈長（学習可能限界）** | KVキャッシュによるメモリ枯渇制限が大きい | 数百万トークンレベルの長文を処理可能 |
| **位置エンコーディング** | **必須** (RoPEや絶対位置埋め込みなど) | **不要** (時系列スキャン自体が暗黙的に位置情報を表現) |
| **GPU並列計算の親和性** | 行列積のみで構成され、標準ライブラリで極めて高速 | 標準PyTorchのForループは低速。高速化にはカスタムカーネルが必須 |
| **局所的なパターンの学習** | Attentionがシーケンス全体を一律に見るためやや苦手 | 内部の1D Conv層により局所パターンの抽出が得意 |

---

## 6. 自己学習に向けた実験ガイド

あなたが [model.py](file:///home/abemc/project_root/src/model.py) に追加した純PyTorch実装を用いて、学習プロセスを観察するためのヒントです。

1. **損失（Loss）の収束速度の比較:**
   - [train_gpt.py](file:///home/abemc/project_root/src/train_gpt.py) で `model_type = 'gpt'` と `model_type = 'mamba'` の設定を切り替え、同等パラメータ数で数ステップ走らせてみてください。Mambaは初期のLossの下がり方がアテンションとどう異なるか、確認できます。
2. **コンテキスト長拡張によるスケーリング確認:**
   - `block_size` を `64` から `128`、`256` と増やしたときに、各エポック・ステップの所要時間がどのように変化するか計測してください。
   - （※Pythonの For ループによる逐次処理のため、純PyTorch版はコンテキスト長に対して動作が著しく遅くなりますが、計算オーダー上のVRAMの消費量の伸びが緩やかであることをプロット等で確認できます）
3. **隠れ状態 $h$ のサイズ実験:**
   - `MambaConfig` の `d_state` を `16` から `32` に変更してみましょう。これは時系列の「記憶容量」を意味します。状態数を増やすことで推論の質（生成テキストの論理整合性）が向上するか観察することができます。
