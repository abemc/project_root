# 2026-05-20 自己学習専用版

このフォルダは、AI/LLM の自己学習に必要な資料だけを集約した専用版です。

## 学習ルート（Mermaid）

```mermaid
flowchart TD
	A["開始"] --> B["llm_intro.md"]
	B --> C["vector_tensor_basics.md"]
	C --> D["math_primer.md"]
	D --> E["ai_math_deep_dive.md"]
	E --> F["transformer_math_map.md"]
	F --> G["examples/_math_drills/vector_tensor_shapes_demo.ipynb"]
	G --> H["examples/_intermediate_topics/attention_math_demo.ipynb"]
	H --> I["examples/_transformer_deep_dive/ffn_mlp_demo.ipynb"]
	I --> J["examples/_transformer_deep_dive/residual_layernorm_demo.ipynb"]
	J --> K["examples/_transformer_deep_dive/positional_encoding_demo.ipynb"]
```

## 目的別インデックス（表）

| 目的 | 最初に読む/実行する資料 | 到達イメージ |
|---|---|---|
| LLM の全体像を掴む | `llm_intro.md` | 用語と全体構造を説明できる |
| 記号の読み方を固める | `数式記号の読み方ガイド.md` → `examples/_math_drills/数式記号_読み方ドリル.ipynb` | 式を見て読み上げ・意味説明ができる |
| 数学基礎を固める | `vector_tensor_basics.md` → `math_primer.md` | shape と勾配の基礎が分かる |
| 初級で内積を固める | `初級_内積入門.md` → `examples/_basic_intro/内積_初級.ipynb` | 内積を手計算とコードで説明できる |
| 中級で Attention へ接続 | `中級_内積とAttention.md` → `examples/_intermediate_topics/内積_attention_中級.ipynb` | scaled dot-product とマスクを説明できる |
| Transformer 数学を理解する | `ai_math_deep_dive.md` → `transformer_math_map.md` | Attention/FFN/LN を式で説明できる |
| 手を動かして定着する | `examples/_basic_intro/` 以降 | 式→コード→挙動を確認できる |

## 含めたもの
- `vector_tensor_basics.md`
- `cheatsheet-ai-basics.md`
- `llm_intro.md`
- `math_primer.md`
- `数式記号の読み方ガイド.md`
- `ai_math_deep_dive.md`
- `ai_math_study_plan_8weeks.md`
- `transformer_math_map.md`
- `glossary.md`
- `初級_内積入門.md`
- `中級_内積とAttention.md`
- `self-study-slides.md`
- `self-study-2026-05-19.md`
- `doc_plan.md`
- `examples/intro.ipynb`
- `examples/llm_hands_on.ipynb`
- `examples/vector_tensor_shapes_demo.ipynb`
- `examples/数式記号_読み方ドリル.ipynb`
- `examples/内積_初級.ipynb`
- `examples/内積_attention_中級.ipynb`
- `examples/grad_desc_viz.ipynb`
- `examples/attention_math_demo.ipynb`
- `examples/ffn_mlp_demo.ipynb`
- `examples/residual_layernorm_demo.ipynb`
- `examples/positional_encoding_demo.ipynb`
- `examples/test_llm_env.py`

## 除外したもの
- 演習問題と解答（`exercises.md`, `solutions/`）

## 推奨の読み順
1. `llm_intro.md`
2. `vector_tensor_basics.md`
3. `数式記号の読み方ガイド.md`
4. `examples/数式記号_読み方ドリル.ipynb`
5. `初級_内積入門.md`
6. `examples/内積_初級.ipynb`
7. `math_primer.md`
8. `ai_math_deep_dive.md`
9. `中級_内積とAttention.md`
10. `examples/内積_attention_中級.ipynb`
11. `ai_math_study_plan_8weeks.md`
12. `transformer_math_map.md`
13. `cheatsheet-ai-basics.md`
14. `examples/vector_tensor_shapes_demo.ipynb`
15. `examples/intro.ipynb`
16. `examples/llm_hands_on.ipynb`
17. `examples/grad_desc_viz.ipynb`
18. `examples/attention_math_demo.ipynb`
19. `examples/ffn_mlp_demo.ipynb`
20. `examples/residual_layernorm_demo.ipynb`
21. `examples/positional_encoding_demo.ipynb`
22. `self-study-slides.md`
