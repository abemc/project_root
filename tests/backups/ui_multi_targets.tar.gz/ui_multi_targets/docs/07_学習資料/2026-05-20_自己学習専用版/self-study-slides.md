---
# AI & LLM 入門 — 速習スライド

---
## 1. 何を学ぶか（概要）
- LLMとは何か：大量データで言語の統計を学習するモデル
- 必要な数学：線形代数（ベクトル/行列）、微分（勾配）、確率の基礎
- 実践：scikit-learn と Hugging Face を使った簡単なハンズオン

---
## 2. LLM の直感的理解
- トークナイザ → トークン列 → モデル（Transformer）→ 次トークン確率
- デコーディングで出力を決定（greedy, sampling, top-k/top-p）

---
## 3. 数学の要点（図解）
- ベクトルは方向と大きさ、行列は線形変換
- 勾配は「最も増加する方向」。最小化は逆向きに進む

簡易図（勾配のイメージ）:

```
  loss
   ^       .   .   .
   |     .       .
   |   .           .
   | .               .
   +--------------------> param
       ^
      decrease (gradient)
```

---
## 4. ハンズオンの進め方
- まず `learning_materials/cheatsheet-ai-basics.md` を読み環境を整える
- `examples/intro.ipynb` を実行して scikit-learn の分類を体験
- `examples/llm_hands_on.ipynb` を Colab かローカルで実行（transformers が必要）

---
## 5. 次のステップ（自己学習ロードマップ）
- 基礎（本資料）を読了 → Notebook を実行
- 興味があれば数学プリマの図解ノート（勾配可視化）を実行
- ゆっくり深めるなら：Transformer の内部（Attention）を可視化する資料へ

---
*ファイル: learning_materials/self-study-slides.md*