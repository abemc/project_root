AI 入門チートシート

目的: AI 初学者が最初に知っておくべきコマンド、概念、デバッグの注意点を短くまとめる。

セットアップ（最小）
- Python 仮想環境の作成と有効化:
```bash
python3 -m venv .venv
source .venv/bin/activate
```
- パッケージのインストール:
```bash
pip install --upgrade pip
pip install numpy pandas scikit-learn matplotlib jupyter
```
- Jupyter を使う場合:
```bash
jupyter notebook
# または Google Colab を使用（インストール不要）
```

基本コマンド（プロジェクト作業）
- テスト実行（全体）: `pytest -q`
- テスト実行（個別）: `pytest -q tests/test_file.py::TestClass::test_method`
- フォーマット（例）: `black .`（導入している場合）
- 仮想環境を抜ける: `deactivate`

git ワークフロー（簡易）
- ブランチ作成: `git checkout -b feature/your-topic`
- 変更をステージしてコミット: `git add . && git commit -m "message"`
- リモートへ push: `git push origin feature/your-topic`

よく使う Python スニペット
- 仮想環境の Python を使って pytest を実行:
```bash
.python -m pytest -q
# 例: /home/user/.venv/bin/python -m pytest -q
```
- 簡単な scikit-learn の学習・予測フロー（概念）:
 1. データ読み込み (`pandas.read_csv`)  
 2. 前処理（欠損値・カテゴリ変換・標準化）  
 3. モデル定義 (`sklearn` の estimator)  
 4. `fit()` → `predict()` → 指標計算（accuracy, precision）

非同期 & subprocess の注意点
- coroutine を忘れず `await` する（未 await の coroutine は ResourceWarning / RuntimeWarning を発生）
- `subprocess.Popen` に `timeout` 引数は無い（`communicate(timeout=...)` を使う）
- 外部コマンドの出力を扱うときは `decode('utf-8', errors='replace')` を使うと安全

pytest のデバッグヒント
- 失敗の要因を絞る: `-k` (keyword) を使う: `pytest -k "permission and can_execute"`
- 最初に止める: `-x` を使うと最初の失敗で停止する
- 詳細ログ: `-q` を外して詳細出力、または `-q -k PATTERN -vv`
- Fixture のスコープとライフサイクルを理解する（function/module/session）
- テストで `return` を使わない → `assert` を使う

よくある落とし穴（チェックリスト）
- 非同期関数を await しているか
- API の戻り値の型はドキュメントどおりか（例: `can_execute()` が bool を返すか）
- subprocess の呼び出しで無効な引数を渡していないか
- 依存グラフの循環は早期に検出されているか
- テストの戻り値を `assert` で検証しているか

追加リソース（初心者向け）
- Python: https://docs.python.org/3/
- scikit-learn チュートリアル: https://scikit-learn.org/stable/tutorial/
- pytest: https://docs.pytest.org/
- Jupyter / Colab: https://jupyter.org/  https://colab.research.google.com/

ファイル配置の推奨
- ノートブック: `learning_materials/examples/intro.ipynb`
- チートシート: `learning_materials/cheatsheet-ai-basics.md`
- スライド: `learning_materials/self-study-slides.pdf` (または PPTX)

---
作成: 自動生成チートシート（要カスタマイズ）
