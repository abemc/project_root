# ベクトル・行列・テンソル超入門（AI 初学者向け）

目的: LLM/Deep Learning を学ぶ前に、式と実装で頻出する最小限の線形代数を身につける。

> 📖 **用語集**: わからない用語は [glossary.md](glossary.md) を参照してください。

## 1. まず結論
- [ベクトル](glossary.md#ベクトル): 1次元の数列（例: 単語埋め込み 1個）
- [行列](glossary.md#行列): 2次元の表（例: バッチ分の埋め込みを並べたもの）
- [テンソル](glossary.md#テンソル): 3次元以上も含む多次元配列（例: ミニバッチのトークン列全体）

## 2. 形（shape）だけ先に覚える
- ベクトル: `(d,)`
- 行列: `(n, d)`
- 3次元テンソル: `(b, t, d)`

意味の例:
- `b`: バッチサイズ
- `t`: トークン数（系列長）
- `d`: 特徴量次元（埋め込み次元）

### shape 対応表

| 記号 | 代表 shape | 意味 |
|---|---|---|
| `x` | `(d,)` | 1つの入力ベクトル |
| `X` | `(b, d)` | バッチ入力 |
| `W` | `(d_in, d_out)` | 線形変換の重み |
| `Q, K, V` | `(b, h, t, d_k)` | Attention 用のクエリ・キー・バリュー |
| `score` | `(b, h, t, t)` | トークン間の関連スコア |
| `output` | `(b, h, t, d_k)` | Attention の出力 |

## 3. AI でよく使う演算
- [内積](glossary.md#内積): 2つのベクトルの類似度の基本
- [行列積](glossary.md#行列積): 線形変換（重みをかける処理）
- [転置](glossary.md#転置): 軸を入れ替える（`A.T`）
- 要素ごとの演算: 同じ [shape](glossary.md#shape) 同士で足し算や掛け算

## 4. 最小の数式
- 内積: $x \cdot y = \sum_i x_i y_i$
- 線形変換: $y = xW + b$
- ミニバッチ線形変換: $Y = XW + b$

shape 対応:
- `X`: `(b, d_in)`
- `W`: `(d_in, d_out)`
- `Y`: `(b, d_out)`

## 5. Attention でのテンソルの見方
典型 [shape](glossary.md#shape):
- [`Q, K, V`](glossary.md#qkv): `(b, h, t, d_k)`
- スコア: `Q @ K^T` → `(b, h, t, t)`
- 出力: [`softmax`](glossary.md#ソフトマックス)`(score) @ V` → `(b, h, t, d_k)`

ここで大事なのは「値」より先に「shape」が合っているかを確認すること。

→ [Attention の詳細は用語集へ](glossary.md#attention)

### Attention の流れ（Mermaid 図）

```mermaid
flowchart LR
    X["Input X<br/>shape: (b,t,d_model)"] --> LQ["Linear for Q"]
    X --> LK[Linear for K]
    X --> LV[Linear for V]
    LQ --> Q["Q<br/>(b,h,t,d_k)"]
    LK --> K["K<br/>(b,h,t,d_k)"]
    LV --> V["V<br/>(b,h,t,d_k)"]
    Q --> MM1["Q @ K^T"]
    K --> MM1
    MM1 --> S["score<br/>(b,h,t,t)"]
    S --> SM["softmax on last axis"]
    SM --> MM2["weights @ V"]
    V --> MM2
    MM2 --> O["output<br/>(b,h,t,d_k)"]
```

## 6. NumPy で確認（そのまま実行可）
```python
import numpy as np

# 1) ベクトル
x = np.array([1.0, 2.0, 3.0])           # (3,)
y = np.array([0.5, -1.0, 2.0])          # (3,)
print("dot:", np.dot(x, y))

# 2) 行列
X = np.array([[1.0, 2.0, 3.0],
              [0.0, 1.0, 0.0]])         # (2, 3)
W = np.array([[1.0, 0.0],
              [0.0, 1.0],
              [1.0, 1.0]])              # (3, 2)
B = np.array([0.1, -0.2])               # (2,)
Y = X @ W + B                            # (2, 2)
print("Y shape:", Y.shape)
print(Y)

# 3) テンソル
T = np.random.randn(2, 4, 8)            # (b=2, t=4, d=8)
print("tensor shape:", T.shape)
```

## 7. 初学者がハマりやすい点
- `(d,)` と `(d,1)` は別物
- 行列積は「内側の次元」が一致していないと失敗する
- ブロードキャストで意図しない計算が起きることがある

## 8. 次に読む資料
1. `math_primer.md`
2. `ai_math_deep_dive.md`
3. `transformer_math_map.md`
4. `examples/vector_tensor_shapes_demo.ipynb`
5. `examples/attention_math_demo.ipynb`

## 9. 30分学習プラン
1. shape の意味を声に出して説明する（5分）
2. NumPy サンプルを実行し shape を確認する（10分）
3. `math_primer.md` の「ベクトルと行列」だけ読む（10分）
4. 最後に「ベクトル/行列/テンソルの違い」を1文で書く（5分）
