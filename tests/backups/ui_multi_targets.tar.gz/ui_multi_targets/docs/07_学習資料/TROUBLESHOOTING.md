# 🔧 トラブルシューティング&FAQ

学習中に遭遇する可能性のあるトラブルと対応方法をまとめています。

---

## 🔴 環境構築の問題

### Q1: `Python` コマンドが見つからない

**症状:**
```bash
$ python --version
bash: python: command not found
```

**原因**: Python がインストールされていない

**対応**:
```bash
# macOS (Homebrew)
brew install python@3.10

# Ubuntu/Debian
sudo apt-get update
sudo apt-get install python3.10

# Windows
# 公式サイト https://www.python.org/downloads/ からダウンロード
```

確認:
```bash
python3.10 --version  # 3.10.x が表示されればOK
```

---

### Q2: `pip install` で「Permission denied」エラー

**症状:**
```
ERROR: Could not install packages due to a PermissionError
```

**原因**: システムの Python に直接インストールしようとしている

**対応**:
```bash
# 仮想環境を有効化してから実行
cd /home/abemc/project_root
source .venv/bin/activate  # macOS/Linux
# または
.venv\Scripts\activate  # Windows

# その後
pip install -r requirements.txt
```

---

### Q3: 仮想環境が有効になっていない

**症状**: プロンプトに `(.venv)` が表示されない

```bash
$ python --version
Python 3.9.0  # 古いバージョンが表示される
```

**対応**:
```bash
# 仮想環境を有効化
cd /home/abemc/project_root
source .venv/bin/activate

# 確認
which python
# 出力: /home/abemc/project_root/.venv/bin/python ← この形式ならOK
```

---

### Q4: `test_llm_env.py` を実行してエラーが出る

**症状**:
```
ModuleNotFoundError: No module named 'torch'
```

**対応**:
```bash
# 仮想環境が有効か確認
source /home/abemc/project_root/.venv/bin/activate

# ライブラリをインストール
pip install -r /home/abemc/project_root/requirements.txt

# 再度テスト
python /home/abemc/project_root/docs/07_学習資料/2026-05-20_自己学習専用版/examples/_utility/test_llm_env.py
```

---

### Q5: GPU (CUDA) が使える環境かテストしたい

**症状**: GPU がある環境で、CPU モードで動作している

**確認方法**:
```bash
python -c "import torch; print(torch.cuda.is_available())"
```

**出力**:
- `True` → GPU が使える（CUDA インストール済）
- `False` → GPU が使えない or CUDA がインストールされていない

**対応** (GPU を使いたい場合):
```bash
# PyTorch を GPU 対応版に再インストール
pip uninstall torch
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

---

## 🟡 Jupyter Notebook のトラブル

### Q6: Notebook が開かない / 起動しない

**症状**:
```bash
$ jupyter notebook
bash: jupyter: command not found
```

**対応**:
```bash
# 仮想環境が有効か確認
source /home/abemc/project_root/.venv/bin/activate

# Jupyter をインストール
pip install jupyter

# 起動
jupyter notebook
```

---

### Q7: Notebook で `ModuleNotFoundError` が出る

**症状**:
```python
import torch
ModuleNotFoundError: No module named 'torch'
```

**原因**: Notebook が、仮想環境のない Python で起動している

**対応**:

**方法 A: Notebook を正しい環境で起動**
```bash
# 1. 仮想環境を有効化
source /home/abemc/project_root/.venv/bin/activate

# 2. Jupyter を起動
jupyter notebook

# 3. ブラウザで Notebook を開く
```

**方法 B: VS Code を使う場合**
```
1. Python インタプリタを選択: Cmd/Ctrl + Shift + P
2. "Python: Select Interpreter" を検索
3. .venv の Python を選択
4. Notebook を実行
```

---

### Q8: Notebook のセルを実行してもハングする

**症状**: セル実行後、ずっと `In [*]` の状態で終わらない

**対応**:
```
1. Kernel を再起動: Kernel > Restart Kernel
2. 長時間計算が必要な場合は、少し待つ
3. それでも終わらなければ Jupyter を再起動
```

---

### Q9: Notebook の出力が古い（修正後も同じ結果が表示される）

**症状**: コード変更後も、古い計算結果が表示される

**対応**:
```
1. Kernel > Restart Kernel（Jupyter UI）
2. すべてのセルをリセット: Kernel > Restart and Clear Output
3. 上からセルを順に実行し直す
```

---

## 🟠 実行時エラー

### Q10: `ImportError` or `ModuleNotFoundError`

**症状**:
```python
from transformers import AutoModelForCausalLM
ModuleNotFoundError: No module named 'transformers'
```

**対応**:
```bash
# 仮想環境を有効化
source /home/abemc/project_root/.venv/bin/activate

# 不足しているライブラリをインストール
pip install transformers

# または全て再インストール
pip install -r requirements.txt
```

---

### Q11: `OutOfMemoryError` (メモリ不足)

**症状**:
```
RuntimeError: CUDA out of memory.
```

**対応**:
```python
# モデルのバッチサイズを減らす
batch_size = 1  # 小さくする

# または計算グラフをクリア
import torch
torch.cuda.empty_cache()

# CPU で実行する
device = 'cpu'  # GPU の代わりに CPU を使う
```

---

### Q12: `torch.cuda.is_available()` が False なのに GPU を認識したい

**症状**: GPU があるのに、PyTorch が認識していない

**対応**:
```bash
# CUDA・cuDNN をインストール
# https://docs.nvidia.com/cuda/cuda-installation-guide-linux/ 参照

# または PyTorch を CUDA 対応版に再インストール
pip install torch --index-url https://download.pytorch.org/whl/cu121
```

---

## 🔵 学習資料・Notebook のトラブル

### Q13: PDF ファイルが開かない

**症状**: PDF をクリックしても開かない、または文字が化ける

**対応**:
```
1. ブラウザで開く: PDF 右クリック → ブラウザで開く
2. 標準 PDF ビューア: Adobe Reader など
3. テキスト版を読む: 同じフォルダの README.md で内容確認
```

---

### Q14: Notebook が古いバージョンのコードを含んでいる

**症状**: 教材の内容が古い or バグがある

**対応**:
1. GitHub Issues に報告
2. README.md の更新情報を確認
3. 新しい Notebook をダウンロード

---

### Q15: 「このファイルはどこにあるのか分からない」

**症状**: 教材の参照パスが複雑

**対応**:
```bash
# ファイル検索
find /home/abemc/project_root/docs/07_学習資料 -name "*.ipynb" | grep -i "attention"
```

---

## 🟢 学習上のトラブル

### Q16: 「コードは理解できるが、理論が分からない」

**症状**: Notebook は実行できるが、なぜこうなるのか分からない

**対応**:
```
推奨順序:
1. foundation_math/ で数学基礎を学ぶ
2. MD ファイルで理論を読む
3. Notebook で実装を確認
```

例: Attention が分からない場合
```
1. foundation_math/プロジェクトに必要な数学基礎.md
2. 2026-05-20_自己学習専用版/中級_内積とAttention.md
3. examples/_intermediate_topics/内積_attention_中級.ipynb
```

---

### Q17: 「Notebookを実行したが、何を学んだのか分からない」

**症状**: セルを実行して出力が出たが、意味が不明

**対応**:
```
1. Notebook の前にあるの MD ファイルを読む
2. 各セルの説明をよく読む
3. パラメータを変更して実験
4. 出力の意味を「自分の言葉」で説明する
```

---

### Q18: 「学習時間が予定より長くなっている」

**症状**: LEARNING_TIMELINE.md の計画より遅れている

**対応**:
```
1. スキップできない章を特定（基礎か応用か）
2. 詳細は後で学ぶ → 全体像を先に理解
3. 時間計画を調整する
4. 「完璧を目指さない」ことが成功の鍵
```

---

### Q19: 「書いているコードがエラーになる」

**症状**: Notebook のコードをコピーして実行したがエラー

**対応**:
```
1. Python バージョンを確認（3.8 以上か）
2. 必要なライブラリがインストール済か確認
3. インデント（スペース）が正しいか確認
4. エラーメッセージをよく読む
```

---

## 📞 上記にない問題が発生した場合

### ステップ 1: エラーメッセージをよく読む
```
「何が」「どこで」「なぜ」エラーが出ているか？
```

### ステップ 2: Google で検索
```
エラーメッセージ + Python or PyTorch
```

### ステップ 3: README や他の教材を確認
```
同じエラーが他の場所で説明されていないか
```

### ステップ 4: 環境をリセット
```bash
# 仮想環境を作り直す
cd /home/abemc/project_root
rm -rf .venv
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

---

## ⚡ よくある質問（FAQ）

### Q: 「Transformerってなに？」
→ [01_LLM_basics/README.md](01_LLM_basics/README.md) を読んでください

### Q: 「PyTorch の基本を学びたい」
→ [foundation_math/](foundation_math/) → 公式チュートリアル

### Q: 「GPUでの学習を高速化したい」
→ [04_inference_pipeline/README.md](04_inference_pipeline/README.md)

### Q: 「このプロジェクトをカスタマイズしたい」
→ [05_advanced_implementation/README.md](05_advanced_implementation/README.md)

### Q: 「さらに詳しく学びたい」
→ README.md の「参考資料」セクション

---

## 🆘 サポートを求める場合

以下の情報を用意してから質問してください：

```
1. エラーメッセージ（全文コピー）
2. 実行したコマンド
3. 環境情報
   - Python バージョン
   - OS（macOS/Linux/Windows）
   - ライブラリバージョン（pip list）
4. 何をしようとしていたか
```

---

**最終更新**: 2026-05-23

**トラブルが解決したら**: [QUICK_START.md](QUICK_START.md) or [LEARNING_TIMELINE.md](LEARNING_TIMELINE.md) に戻って学習を続けてください。
