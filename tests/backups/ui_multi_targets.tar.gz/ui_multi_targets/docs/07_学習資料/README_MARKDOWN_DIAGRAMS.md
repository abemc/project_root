図変換ワークフロー

目的:
- Markdown 内の `mermaid` コードブロックを SVG（もしくは PNG）に変換し、`docs/assets/` に格納する。

手順:
1. Node.js と npm のインストール（未インストールの場合）

```bash
# Debian/Ubuntu 例
sudo apt update
sudo apt install -y nodejs npm
```

2. mermaid-cli をグローバルに入れるか、npx を利用します（推奨: npx）

```bash
# 一度だけグローバルインストールする場合
npm install -g @mermaid-js/mermaid-cli

# または、スクリプトは npx を使うので追加不要
```

3. 画像を生成する

```bash
# 生成のみ（Markdown を書き換えない）
python3 scripts/render_mermaid.py

# 生成して Markdown を画像リンクで置換する
python3 scripts/render_mermaid.py --apply
```

注意:
- CI で自動生成する場合は、ビルドステップで `npm ci` と `npx @mermaid-js/mermaid-cli` を使って生成することを推奨します。
- Git 管理下に大きなバイナリを増やしたくない場合は、生成物を `docs/assets/` に格納し、`.gitignore` の運用を検討してください。
