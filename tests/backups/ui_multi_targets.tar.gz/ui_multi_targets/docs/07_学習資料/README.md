# 📚 学習資料ディレクトリガイド

このディレクトリは、プロジェクトに関する包括的な学習材料を体系的に整理しています。

---

## 🚀 初めての方へ - まずはここから

初心者の方は、**以下の順**で読んでください：

| ドキュメント | 目的 | 時間 |
|-----------|------|------|
| [**PREREQUISITES.md**](PREREQUISITES.md) | 環境チェック・前提知識確認 | 1時間 |
| [**QUICK_START.md**](QUICK_START.md) | 初日～3日間の学習ガイド | 10-13時間 |
| [**LEARNING_TIMELINE.md**](LEARNING_TIMELINE.md) | 1週間以降の計画を立てる | 参考用 |
| [**TROUBLESHOOTING.md**](TROUBLESHOOTING.md) | 困ったときはここを見る | 問題発生時 |

**現在の状況別リンク**:
- 🟢 **環境が整っている** → [QUICK_START.md](QUICK_START.md) へ
- 🟡 **セットアップが必要** → [PREREQUISITES.md](PREREQUISITES.md) へ
- 🔴 **エラーが出ている** → [TROUBLESHOOTING.md](TROUBLESHOOTING.md) へ

---

## 📖 学習フロー

```
01. LLM基礎
    ↓
02. プロジェクト概要理解
    ↓
03. セットアップと実装開始
    ↓
04. 推論パイプライン分析
    ↓
05. 応用実装と最適化
    ↓
+ foundation_math（並行学習推奨）
+ 2026-05-20_自己学習専用版（実装演習）
```

---

## 📂 ディレクトリ構成

### 段階的教材（順序付き）

#### **01_LLM_basics** - LLM基礎入門
- **対象**: LLMを初めて学ぶ方
- **内容**: LLMの基本概念、アーキテクチャ、言語モデルの原理
- **ファイル**: README.md（ガイド）、content.pdf（ビジュアル資料）

#### **02_project_overview** - プロジェクト概要
- **対象**: 本プロジェクトの全体像を理解したい方
- **内容**: システムアーキテクチャ、コンポーネント関係図
- **ファイル**: README.md（説明）、diagram.pdf（アーキテクチャ図）

#### **03_setup_hands_on** - セットアップと実装開始
- **対象**: 環境構築から実装を始める方
- **内容**: 開発環境構築、初期実装、ハンズオン
- **ファイル**: README.md（ガイド）、guide.pdf（マニュアル）

#### **04_inference_pipeline** - 推論パイプライン分析
- **対象**: 推論処理の詳細を理解したい方
- **内容**: パイプライン設計、最適化手法、パフォーマンス分析
- **ファイル**: README.md（分析レポート）、analysis.pdf（詳細分析）

#### **05_advanced_implementation** - 応用実装ガイド
- **対象**: 高度な機能実装を目指す方
- **内容**: 最適化技法、カスタム実装、デバッグ方法
- **ファイル**: README.md（ガイド）、guide.pdf（テクニック）

---

### 基礎学習サポート

#### **foundation_math** - 数学基礎と実装詳細
- **対象**: 数学的背景を深めたい方
- **内容**:
  - プロジェクトに必要な数学基礎
  - ニューラルネットワーク完全ガイド
  - テキスト埋め込み実装ガイド
  - バッチ処理とパディング詳細

---

### 自己学習実践版

#### **2026-05-20_自己学習専用版**
- **対象**: 実装演習を通して学びたい方
- **構成**:
  
  📄 **ドキュメント（root）**
  - 学習ロードマップ（8週間プラン）
  - AI数学の深掘り
  - Transformer数学マップ
  - 用語集、数式ガイド
  - チートシート

  💻 **examples/ - 実装演習**
  
  - **_basic_intro/** - 基礎演習
    - `intro.ipynb` - 初めの一歩
    - `llm_hands_on.ipynb` - LLMハンズオン
    - `内積_初級.ipynb` - 内積の基礎
    
  - **_intermediate_topics/** - 中級演習
    - `内積_attention_中級.ipynb` - 内積からAttentionへ
    - `attention_math_demo.ipynb` - Attention機構のデモ
    - `中級_内積とAttention.md` - 詳細解説
    
  - **_transformer_deep_dive/** - Transformer深掘り
    - `ffn_mlp_demo.ipynb` - FFN/MLP層
    - `residual_layernorm_demo.ipynb` - 残差接続とLayerNorm
    - `positional_encoding_demo.ipynb` - 位置エンコーディング
    
  - **_math_drills/** - 数学演習
    - `grad_desc_viz.ipynb` - 勾配降下の可視化
    - `vector_tensor_shapes_demo.ipynb` - テンソル形状演習
    - `数式記号_読み方ドリル.ipynb` - 数式ドリル
    
  - **_utility/** - ユーティリティ
    - `test_llm_env.py` - 環境テスト
    - `flowchart LR.mmd` - フローチャート

---

### アーカイブ

#### **archived/** - 過去バージョン・バックアップ
- 廃止予定のファイル、バージョン管理用

---

## 🎯 推奨学習パス

### 初心者向け（0～2週間）
```
1. 01_LLM_basics/ で概念を学ぶ
2. 02_project_overview/ でプロジェクトを理解
3. 2026-05-20_自己学習専用版/_basic_intro/ で実装開始
4. foundation_math/ で必要な数学を補強
```

### 中級者向け（2～4週間）
```
1. 03_setup_hands_on/ で環境構築・実装
2. 2026-05-20_自己学習専用版/_intermediate_topics/ で中級演習
3. foundation_math/ で詳細を理解
```

### 上級者向け（4週間以上）
```
1. 04_inference_pipeline/ でパフォーマンス分析
2. 05_advanced_implementation/ で応用実装
3. 2026-05-20_自己学習専用版/_transformer_deep_dive/ で深掘り
```

---

## 💡 各教材の活用方法

| 教材 | 推奨方法 | 期間 |
|------|--------|------|
| MD ファイル | テキストとして読み進める | 1-3時間 |
| PDF ファイル | 図解や詳細レイアウトを確認 | 1-2時間 |
| Notebook | 対話的に実行・編集して学ぶ | 2-4時間 |
| 数学基礎 | 必要に応じて参照・深掘り | 随時 |

---

## 🔗 関連リソース

### 📍 学習支援ドキュメント
- [PREREQUISITES.md](PREREQUISITES.md) - 環境チェック・前提知識
- [QUICK_START.md](QUICK_START.md) - 初日～3日間ガイド
- [LEARNING_TIMELINE.md](LEARNING_TIMELINE.md) - 1週間以降の計画
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - トラブルシューティング・FAQ
- [KB_詳細ガイド.md](KB_詳細ガイド.md) - KBの役割・保存契機・保持ポリシー

### 🏗️ プロジェクト構成
- メインプロジェクト: `/home/abemc/project_root`
- 実装コード: `src/` ディレクトリ
- テストコード: `tests/` ディレクトリ
- 設定ファイル: `config/` ディレクトリ

---

**Last Updated**: 2026-05-23
**Learning Materials Version**: 2.0
