# ✅ 前提知識・環境チェック

このプロジェクトを学ぶために必要な前提知識と、環境セットアップのチェックリストです。

---

## 📋 前提知識チェックリスト

### 🟢 必須（このプロジェクトで学べます）

#### Python プログラミング
- ✅ 変数、リスト、辞書の基本操作
- ✅ 関数定義と呼び出し
- ✅ for/while ループ、if-else
- ✅ ファイル I/O

**学習時間**: 既に知っていることを前提（未習者は別途 Python 基礎講座が必要）

---

#### 線形代数の基本（超基本）
- ✅ ベクトルとは何か（数値の配列）
- ✅ ベクトルの内積（2つの数列の掛け算と足し算）
- ✅ 行列とは何か（ベクトルの集まり）

**学習時間**: このプロジェクトの `foundation_math/` で補強可能

---

### 🟡 あると便利だが学習中に習得可能

#### NumPy / PyTorch の基本
- ベクトル・行列操作
- テンソル操作

**推奨**: 2026-05-20_自己学習専用版/examples/_math_drills/ で学べます

---

#### 微積分の基本概念
- 関数と導関数
- 勾配（gradient）
- チェーンルール

**推奨**: foundation_math/ で詳細あり

---

### 🔴 事前に知っておくべきドメイン知識はありません

- 言語学の知識？ → 不要
- 機械学習の経験？ → 不要
- GPU/CUDA？ → 不要（CPUで学習可能）

---

## 🖥️ 環境セットアップチェック

### ステップ 1: Python バージョン確認

```bash
python --version
```

**要件**: Python 3.8 以上（3.10 推奨）

**問題**:
- バージョンが 3.7 以下 → 新しい Python をインストール
- コマンドが見つからない → [TROUBLESHOOTING.md#Python がインストールされていない](TROUBLESHOOTING.md) 参照

---

### ステップ 2: 仮想環境の確認

```bash
# 仮想環境が有効か確認（プロンプトに括弧がついているか）
which python
```

**期待される出力**:
```
/home/abemc/project_root/.venv/bin/python
```

**問題**:
- `/usr/bin/python` が表示される → 仮想環境が有効でない
  ```bash
  source /home/abemc/project_root/.venv/bin/activate
  ```

---

### ステップ 3: 必要なライブラリが入っているか確認

```bash
python /home/abemc/project_root/docs/07_学習資料/2026-05-20_自己学習専用版/examples/_utility/test_llm_env.py
```

**期待される出力例**:
```
✅ Python 3.10.13
✅ NumPy 1.26.0
✅ PyTorch 2.6.0+cpu
✅ Jupyter 1.0.0
✅ Transformers 4.40.0
```

---

### ステップ 4: ライブラリがない場合

```bash
cd /home/abemc/project_root
pip install -r requirements.txt
```

**所要時間**: 5-10分（ネットワーク速度に依存）

---

## 🔧 トラブル対応

### Python がインストールされていない

```bash
# macOS
brew install python@3.10

# Ubuntu/Debian
sudo apt-get install python3.10 python3.10-venv

# Windows
# → https://www.python.org/downloads/ からダウンロード
```

---

### pip コマンドが見つからない

```bash
# Python 3.10 では pip が一緒に入っています
python3.10 -m pip --version
```

---

### 仮想環境を新しく作りたい場合

```bash
cd /home/abemc/project_root
python -m venv .venv
source .venv/bin/activate  # macOS/Linux
# または
.venv\Scripts\activate  # Windows
pip install -r requirements.txt
```

---

## 📚 前提知識が不足している場合

### Python の基本から学ぶ

外部リソース:
- [Python 公式チュートリアル](https://docs.python.org/ja/3.10/tutorial/)
- [Python for Everybody](https://www.py4e.com/)（日本語版あり）

**このプロジェクトには含まれていません**

---

### NumPy の基本を学ぶ

**このプロジェクト内で学習**:
```
2026-05-20_自己学習専用版/examples/_math_drills/
├─ vector_tensor_shapes_demo.ipynb（テンソル形状）
└─ 数式記号_読み方ドリル.ipynb（数学記号）
```

---

### 線形代数を学ぶ

**このプロジェクト内で学習**:
```
foundation_math/
├─ プロジェクトに必要な数学基礎.md
└─ vector_tensor_basics.md（2026-05-20_自己学習専用版/）
```

---

### 微積分・勾配を学ぶ

**このプロジェクト内で学習**:
```
2026-05-20_自己学習専用版/examples/_math_drills/
└─ grad_desc_viz.ipynb（勾配降下の可視化）
```

---

## 🎯 環境セットアップ完了チェック

全て ✅ が付けば、[QUICK_START.md](QUICK_START.md) に進むことができます。

- [ ] Python 3.8 以上がインストールされている
- [ ] 仮想環境が有効になっている
- [ ] test_llm_env.py を実行してエラーが出ていない
- [ ] 全ての必要なライブラリがインストール済
- [ ] Jupyter Notebook が起動できる（オプション確認）

---

## 📞 環境セットアップで問題が発生した場合

→ [TROUBLESHOOTING.md#環境構築](TROUBLESHOOTING.md) に詳細な対応方法を記載しています。

---

## 🚀 セットアップ完了後

→ [QUICK_START.md](QUICK_START.md) から学習を開始してください。

**次のステップ**:
```
1. QUICK_START.md（初日3日間）
2. LEARNING_TIMELINE.md（1週間以上の計画）
3. README.md（教材の詳細）
```

---

**最終更新**: 2026-05-23
