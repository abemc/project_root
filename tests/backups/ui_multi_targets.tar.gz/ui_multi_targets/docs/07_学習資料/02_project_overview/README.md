# 📚 プロジェクト概要 - プロジェクト全体像を理解する

このセクションは、プロジェクトの**全体構造とデータフロー**を学ぶための教材です。

---

## 🎯 学習目標

このセクションを完了すると：
- ✅ プロジェクトの主要コンポーネントが何かを知る
- ✅ ユーザーからの質問がどのように処理されるか理解する
- ✅ 各レイヤー（UI・処理・学習）の役割を把握する

---

## 📖 推奨読む順序

| # | ドキュメント | 内容 | 時間 |
|---|-----------|------|------|
| 1️⃣ | **このファイル** | 簡潔な説明 | 15分 |
| 2️⃣ | **[ARCHITECTURE.md](ARCHITECTURE.md)** ⭐ 詳しく | 図表で詳細に学ぶ | 30-45分 |
| 3️⃣ | **[../KB_詳細ガイド.md](../KB_詳細ガイド.md)** | KB の設計・保存運用を学ぶ | 20-30分 |
| 4️⃣ | 他の教材 | 個別コンポーネント | 随時 |

---

## 🏗️ システム構成の全体図

```mermaid
graph TB
    subgraph "UI層"
        User["👤 ユーザー"]
        Dashboard["📱 Dashboard"]
        Admin["⚙️ Admin"]
    end

    subgraph "コア処理層"
        API["API"]
        Agent["🤖 Agent"]
        Model["🧠 LLM"]
        RAG["🔍 RAG"]
    end

    subgraph "学習・最適化層"
        Scorer["📊 Scorer"]
        FineTune["🎓 FineTune"]
        KB["📚 KB"]
    end

    Feedback["💾 Feedback"]

    User -->|質問| Dashboard
    User -->|管理| Admin
    Dashboard -->|リクエスト| API
    Admin -->|設定| API
    API -->|処理| Agent
    Agent -->|検索| RAG
    Agent -->|推論| Model
    Agent -->|評価| Scorer
    RAG -->|検索| KB
    KB -->|結果| RAG
    Scorer -->|スコア| Feedback
    Feedback -->|学習| FineTune
    FineTune -->|更新| Model
    Model -.->|出力| Dashboard

    classDef ui fill:#ffffcc,stroke:#ff9900
    classDef core fill:#ccf5ff,stroke:#0099ff
    classDef learn fill:#e6ccff,stroke:#9933ff

    class User,Dashboard,Admin ui
    class API,Agent,Model,RAG core
    class Scorer,FineTune,KB,Feedback learn
```

---

## 📋 コンポーネント一覧

### 🟨 ユーザーインターフェース層

| コンポーネント | 役割 |
|-----------|------|
| **Dashboard** | ユーザーが質問を入力し、回答を見る画面 |
| **Admin Panel** | システム管理者がシステムを設定・管理 |

### 🔵 コア処理層

| コンポーネント | 役割 |
|-----------|------|
| **API Gateway** | Dashboard からのリクエストを受け付け、処理を振り分ける |
| **Agent** | ユーザー質問の内容を理解し、どう処理するか決める（司令官） |
| **LLM** | 自然言語を理解して、テキストを生成（言語モデル） |
| **RAG** | 知識ベースから関連情報を検索し、LLM の精度を高める |
| **Knowledge Base** | プロジェクトの全ての知識・データを保管 |

### 🟣 学習・最適化層

| コンポーネント | 役割 |
|-----------|------|
| **Scorer** | 生成された回答の品質をスコア化 |
| **Feedback** | スコアと回答を記録し、学習データとして保管 |
| **FineTune** | 学習データからモデルのパラメータを改善 |

---

## 📚 KB（Knowledge Base）を先に押さえる理由

このプロジェクトでは、RAG の検索先である KB を理解すると、
「なぜその回答が出るのか」を追いやすくなります。

### KBを理解すると得られること

1. 推論の根拠が見える
- 回答の元データがどこから来たかを説明しやすくなる

2. キャッシュと長期知識を区別できる
- TTL設定は主にキャッシュであり、KB本体は別管理であることを理解できる

3. 運用トラブルに強くなる
- バックアップ/復元の手順を把握して、誤操作時の復旧がしやすくなる

### まず読む資料

- [KB_詳細ガイド.md](../KB_詳細ガイド.md)

### 関連実装（運用で見ることが多い順）

- [manage_kb.py](../../../manage_kb.py): バックアップ/復元のCLI
- [rag_agent_config.py](../../../rag_agent_config.py): RAG設定の既定値
- [.env.production](../../../.env.production): キャッシュ系の実運用設定

---

## 🔄 ユーザー質問の処理フロー

```
1️⃣ ユーザー が Dashboard に質問を入力
   ↓
2️⃣ API Gateway が リクエストを受け取る
   ↓
3️⃣ Agent が 質問を分析・処理計画を立てる
   ↓
4️⃣ RAG が 知識ベースから 関連情報を検索
   ↓
5️⃣ LLM が 情報をもとに 回答を生成
   ↓
6️⃣ Scorer が 回答の品質を 評価
   ↓
7️⃣ Dashboard に 回答が表示される
   ↓
8️⃣ スコア と 回答が Feedback で記録
   ↓
9️⃣ FineTune が 定期的に LLM を改善
```

---

## 💡 Key Points

### 🎯 ドメイン判定
- Agent が質問の「種類」を自動判定
- 商品 / ニュース / 天気 / FAQ などの領域ごとに処理を切り替え

### 🎯 検索増強生成（RAG）
- 単なる LLM ではなく、知識ベース検索と組み合わせ
- 精度の高い、根拠のある回答を生成

### 🎯 継続的改善
- 毎回の回答がスコア付けされる
- 低いスコアの事例から学習
- 定期的にモデルを改善

---

## 🔗 詳しく学ぶには

👉 **[ARCHITECTURE.md](ARCHITECTURE.md)** を読んでください

以下の内容が含まれます：
- 📊 **3層構造の詳細図**
- 🔄 **データフロー図**
- 📋 **各コンポーネント詳細表**
- 🎯 **処理フローの詳細**
- 🔧 **ファイル構成との対応**
- 🚀 **実装パスガイド**

---

**所要時間**: 15分（詳しく学ぶなら 1時間）

**次のステップ**: [ARCHITECTURE.md](ARCHITECTURE.md) → より詳しい図表で理解を深める