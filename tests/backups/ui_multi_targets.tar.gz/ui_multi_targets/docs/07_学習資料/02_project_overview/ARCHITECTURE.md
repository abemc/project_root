# 🏗️ プロジェクトアーキテクチャ完全ガイド

このプロジェクトの構造、データフロー、各コンポーネントの役割を図表で詳しく説明します。

---

> **注記 — 「3層構造」について**
>
> 本ドキュメントで示す「3層（ユーザーインターフェース / コア処理 / 最適化・学習）」は、システム設計上の責務分離パターンです。すべての AI モデルや実装がこの形に従う必要はありません。モデル内部の「層（レイヤー）」概念（例：ニューラルネットワークの入力・隠れ・出力層）とは別のレイヤリングです。
>
> 代表的な差異:
> - 小規模・組み込み: 単一プロセスに統合して低レイテンシを優先することがある
> - 実験プロトタイプ: 開発速度を優先しモノリシック構成にする場合がある
> - 大規模運用: コア層をさらに細分化（retriever, ranker, generator, policy など）し、学習パイプラインを独立させることが多い
>
> 運用上の判断基準:
> - 要件が「監査・説明責任・データ保持」を必要とするか → 3層以上の分離を推奨
> - 要件が「超低レイテンシ／リソース制約」か → モノリシックやエッジ重視の設計を検討
> - チームや組織のスケーリング要件が大きいか → サービス分割（マイクロサービス化）を検討


## 📊 全体アーキテクチャ（3層構造）

```mermaid
graph TB
    subgraph "🔷 ユーザーインターフェース層"
        User["👤 ユーザー"]
        Dashboard["📱 Dashboard"]
        Admin["⚙️ Admin Panel"]
    end

    subgraph "🟠 コア処理層"
        API["API Gateway"]
        Agent["🤖 Agent<br/>(意思決定エンジン)"]
        Model["🧠 LLM<br/>(言語モデル)"]
        RAG["🔍 RAG<br/>(検索＆検索増強)"]
    end

    subgraph "🔵 最適化・学習層"
        Scorer["📊 Scorer<br/>(品質評価)"]
        FineTune["🎓 FineTune<br/>(パラメータ調整)"]
        KB["📚 Knowledge Base<br/>(知識ベース)"]
    end

    Feedback["💾 Feedback Loop<br/>(学習データ)"]

    User -->|質問入力| Dashboard
    User -->|設定管理| Admin
    Dashboard -->|リクエスト| API
    Admin -->|設定更新| API
    API -->|処理依頼| Agent
    
    Agent -->|データ検索| RAG
    Agent -->|推論| Model
    Agent -->|品質評価| Scorer
    
    RAG -->|検索| KB
    KB -->|関連情報| RAG
    
    Model -->|回答| Agent
    Scorer -->|スコア| Feedback
    Feedback -->|学習データ| FineTune
    FineTune -->|パラメータ更新| Model

    Model -.->|出力| Dashboard

    classDef ui fill:#ffffcc,stroke:#ff9900
    classDef core fill:#ccf5ff,stroke:#0099ff
    classDef optimize fill:#e6ccff,stroke:#9933ff
    classDef data fill:#ccffcc,stroke:#00cc00

    class User,Dashboard,Admin ui
    class API,Agent,Model,RAG core
    class Scorer,FineTune,KB,Feedback optimize

## 📚 Knowledge Base（KB） — 図注と詳細資料

- **詳細ドキュメント**: [docs/07_学習資料/KB_詳細ガイド.md](docs/07_学習資料/KB_詳細ガイド.md)
- **図注**: アーキテクチャ図中の「KB」ノードは、以下を含む永続化ストアを指します。
  - インデックス（ベクトル索引）
  - 原典／ソース文書（原文アーカイブ）
  - メタデータ（`retriever_version`, `document_id`, `updated_at`）

  保存契機（例: 低スコア事例の収集、人手ラベリング、外部データ取込）や保持期間・世代管理については上記の詳細ドキュメントを参照してください。
```

---

## 🔄 データフロー（ユーザー質問～回答）

### Step 1: ユーザーが質問を入力

```
【Dashboard】
  ↓
ユーザー: "この商品について詳しく教えて"
```

### Step 2: API が処理リクエストを受け取る

```
【API Gateway】
  ↓
- リクエスト検証
- セッション管理
- リクエストを Agent に転送
```

### Step 3: Agent が「ドメイン判定」と「処理計画」

```
【Agent: 意思決定エンジン】
  ↓
1. ドメイン判定: これは「商品」に関する質問
2. 処理計画: 
   - 知識ベースから情報検索
   - LLMで回答生成
   - 品質チェック
```

### Step 4-A: RAG で知識ベース検索

```
【RAG + Knowledge Base】
  ↓
検索: "商品情報"
  ↓
KB から関連情報を取得
  ↓
例: 商品スペック、説明、レビューなど
```

### Step 4-B: Model で回答を生成

```
【LLM】
  ↓
入力: 
  - ユーザー質問
  - RAGで取得した情報
  ↓
処理: 
  - テキスト理解
  - 文脈に合わせた生成
  ↓
出力: 自然な回答テキスト
```

### Step 5: Scorer が回答品質をチェック

```
【Scorer: 品質評価】
  ↓
評価項目:
- 関連性スコア (0-1)
- 信頼性スコア (0-1)
- 流暢性スコア (0-1)
  ↓
総合スコア計算
```

### Step 6: Feedback → Model改善へ

```
【Feedback Loop】
  ↓
品質スコアが低い
  ↓
FineTune が学習データとして保存
  ↓
定期的にパラメータを調整
  ↓
Model の精度向上
```

### Step 7: Dashboard に結果表示

```
【Dashboard → ユーザー】
  ↓
"この商品は...です。詳細は以下の通り..."
```

---

## 📋 各コンポーネントの役割

| コンポーネント | 役割 | 入力 | 出力 | 更新頻度 |
|-----------|------|------|------|--------|
| **Dashboard** | ユーザーインターフェース | ユーザー入力 | 質問/設定 | リアルタイム |
| **Admin Panel** | システム管理・設定 | 管理者設定 | パラメータ更新 | 管理者操作時 |
| **API Gateway** | リクエスト受付・分配 | HTTP リクエスト | JSON レスポンス | リアルタイム |
| **Agent** | 処理判断・オーケストレーション | ユーザー質問 | 処理計画 | リアルタイム |
| **LLM** | 自然言語処理・生成 | テキスト + コンテキスト | 生成テキスト | 月次パラメータ更新 |
| **RAG** | 検索エンジン + 生成統合 | クエリ | 関連情報 | リアルタイム |
| **Knowledge Base** | 知識・データ保管 | インデックスデータ | 検索結果 | 定期更新 |
| **Scorer** | 回答品質評価 | 生成回答 | スコア (0-1) | リアルタイム |
| **Feedback** | 学習データ集約 | スコア + 回答 | 学習データセット | 継続的 |
| **FineTune** | モデル改善 | 学習データ | 更新パラメータ | 週次～月次 |

---

## 🔵 コンポーネント詳細図

### ① ユーザーインターフェース層

```mermaid
graph LR
    U["👤 User"]
    D["📱 Dashboard"]
    A["⚙️ Admin"]
    
    U -->|質問| D
    U -->|管理| A
    
    classDef user fill:#ffffcc,stroke:#ff9900
    class U,D,A user
```

**特徴**:
- ユーザーと System の唯一の接点
- Dashboard: 質問入力、結果表示
- Admin: システム設定、パラメータ管理

---

### ② コア処理層

```mermaid
graph TB
    API["API Gateway<br/>(リクエスト受付)"]
    Agent["Agent<br/>(処理判断)"]
    LLM["LLM<br/>(推論)"]
    RAG["RAG<br/>(検索&検索増強)"]
    KB["Knowledge Base<br/>(知識ベース)"]
    
    API -->|リクエスト| Agent
    Agent -->|クエリ| RAG
    Agent -->|プロンプト| LLM
    RAG -->|検索| KB
    KB -->|結果| RAG
    LLM -->|回答| Agent
    Agent -->|出力| API
    
    classDef core fill:#ccf5ff,stroke:#0099ff
    classDef data fill:#ccffcc,stroke:#00cc00
    class API,Agent,LLM,RAG core
    class KB data
```

**データの流れ**:
1. API が質問を受け取る
2. Agent が処理内容を決定
3. RAG で知識ベース検索
4. LLM で回答生成
5. API が結果を返す

---

### ③ 最適化・学習層

```mermaid
graph TB
    Model["LLM"]
    Scorer["Scorer<br/>(品質評価)"]
    Feedback["Feedback"]
    FineTune["FineTune"]
    
    Model -->|回答| Scorer
    Scorer -->|スコア| Feedback
    Feedback -->|学習データ| FineTune
    FineTune -->|パラメータ更新| Model
    
    classDef optimize fill:#e6ccff,stroke:#9933ff
    class Model,Scorer,Feedback,FineTune optimize
```

**学習ループ**:
1. Model が生成した回答を Scorer が評価
2. スコアが低い → Feedback が記録
3. FineTune が定期的にモデルを改善
4. 精度が向上

---

### RAG → 最適化・学習層へ流す情報（項目と保存例）

RAG が返した検索結果や Agent/Model のやり取りから、最適化・学習層へ渡すべき具体的なデータ項目と保存例です。実務では短期ログ→匿名化→学習用バケットという流れで管理します。

- 検索結果メタデータ（リトリーバルログ）
  - 例: `document_id`, `passage_id`, `relevance_score`, `retrieval_timestamp`, `retriever_version`
  - 用途: 再現性・サンプリング、リトリーバル品質分析

- 取得テキスト（抜粋・コンテキスト）
  - 例: 実際にプロンプトへ挿入した抜粋テキスト（切り出し位置情報付き）
  - 用途: ファインチューニング用のコンテキスト付き訓練例生成

- 埋め込みベクトル / レトリーバル特徴
  - 例: `query_embedding_hash`, `doc_embedding_hash`, `distance`
  - 用途: 埋め込み品質検知、再索引、近傍学習

- プロンプト履歴と最終プロンプト
  - 例: `prompt_template_id`, `prompt_text`, `tokens_used`
  - 用途: プロンプト改善、コスト分析、データセット化

- モデル生成結果と統計
  - 例: `response_text`, `tokens_used`, `processing_time_ms`
  - 用途: スコア付け、誤答ケース抽出、ラベリング

- スコア/評価（Scorer 結果）
  - 例: `relevance`, `factuality`, `fluency`, `overall`
  - 用途: 閾値での収集、教師データ選別

- ユーザー行動／フィードバック
  - 例: 明示的評価（like/dislike）、クリック、follow-up question
  - 用途: RLHF やサンプリング重み付け

- 失敗・例外ログ
  - 例: `no_supporting_evidence`, `incomplete_context`, API エラー等
  - 用途: ルール追加やアノテーション割当

保存例（JSON スニペット）:

```
{
  "case_id": "c20260523_001",
  "query": "この商品について詳しく教えて",
  "retrieval": [
    {"doc_id":"kb_12","passage_id":"p3","score":0.95},
    {"doc_id":"kb_45","passage_id":"p1","score":0.87}
  ],
  "prompt": {"template":"prod_v1","text":"...","tokens":245},
  "response": {"text":"商品Aについて...","tokens":245,"time_ms":1234},
  "scores": {"relevance":0.92,"fluency":0.88,"factuality":0.95},
  "user_feedback": {"action":"accept","timestamp":"2026-05-23T10:35:00Z"}
}
```

運用上の注意点:

- 個人情報は必ず匿名化／マスキングする（PII を除外）
- `retriever_version` / `model_version` を保存して再現性を確保する
- 低スコア事例や高頻度クエリは優先的に人手ラベル化する
- 保存フロー: 短期ログ（Kafka 等）→ オブジェクトストレージ（S3 等）→ 学習用バケット（匿名化済）

---

## 📈 クエリ処理フロー（詳細）

```mermaid
sequenceDiagram
    participant U as 👤 User
    participant D as 📱 Dashboard
    participant API as API Gateway
    participant A as 🤖 Agent
    participant R as 🔍 RAG
    participant M as 🧠 LLM
    participant S as 📊 Scorer

    U->>D: 質問を入力
    D->>API: リクエスト送信
    API->>A: 処理依頼
    
    par 並列処理
        A->>R: 知識検索
        R-->>A: 関連情報
    and
        A->>M: 推論リクエスト
        M-->>A: 生成テキスト
    end
    
    A->>S: 品質評価
    S-->>A: スコア
    
    A-->>API: 結果
    API-->>D: 回答
    D-->>U: 表示
```

---

## 🎯 各フェーズにおけるデータの形式

### フェーズ 1: ユーザー入力

```json
{
  "user_id": "user_123",
  "query": "この商品について詳しく教えて",
  "domain": "auto-detect",
  "timestamp": "2026-05-23T10:30:00Z"
}
```

### フェーズ 2: Agent の処理計画

```json
{
  "query": "この商品について詳しく教えて",
  "detected_domain": "product",
  "plan": [
    {"step": 1, "action": "search", "target": "knowledge_base"},
    {"step": 2, "action": "generate", "target": "llm"},
    {"step": 3, "action": "score", "target": "scorer"}
  ]
}
```

### フェーズ 3: RAG 検索結果

```json
{
  "query": "この商品について",
  "results": [
    {
      "document": "商品A: スペック...",
      "relevance": 0.95
    },
    {
      "document": "商品A: レビュー...",
      "relevance": 0.87
    }
  ]
}
```

### フェーズ 4: LLM 生成

```json
{
  "prompt": "...",
  "response": "商品Aについてですね。以下が詳細です：...",
  "tokens_used": 245,
  "processing_time_ms": 1234
}
```

### フェーズ 5: スコアリング結果

```json
{
  "response": "商品Aについてですね。...",
  "scores": {
    "relevance": 0.92,
    "fluency": 0.88,
    "factuality": 0.95
  },
  "overall_score": 0.91
}
```

---

## 🔧 システムの特徴

### ✅ マルチドメイン対応
```
入力質問が自動的にドメイン判定される
  ├─ 商品情報 → 商品知識ベース検索
  ├─ ニュース → ニュース知識ベース検索
  ├─ 天気 → 外部 API 呼び出し
  ├─ FAQ → FAQ ベース検索
  └─ その他 → デフォルト処理
```

### ✅ 継続的な学習と改善
```
毎回の処理から学習
  ↓
品質スコアが記録される
  ↓
低スコアの事例を集積
  ↓
定期的にファインチューニング
  ↓
モデルの精度向上
```

### ✅ キャッシング＆最適化
```
頻繁に問い合わせられるクエリ
  ↓
キャッシュに保存
  ↓
次回以降は高速応答
  ↓
レスポンス時間短縮
```

---

## 📍 ファイル構成との対応

| ファイル | 機能 | レイヤー |
|---------|------|--------|
| `src/rag/agent.py` | Agent 実装 | コア処理層 |
| `src/rag/llm.py` | LLM インタフェース | コア処理層 |
| `src/rag/rag_engine.py` | RAG 実装 | コア処理層 |
| `src/rag/scorer.py` | Scorer 実装 | 最適化層 |
| `src/rag/fine_tuner.py` | FineTune 実装 | 最適化層 |
| `app.py` | Dashboard | UI層 |
| `dashboard_app.py` | Admin Panel | UI層 |

---

## 🚀 実装パス（初学者向け）

初心者がこのアーキテクチャを理解する推奨順序：

```
Week 1: 全体像
  └─ このドキュメントの「全体アーキテクチャ」図を理解

Week 2: データフロー
  └─ 「ユーザー質問～回答」フローを追える

Week 3: 個別コンポーネント
  └─ 各レイヤーの詳細図を学ぶ

Week 4: コード実装
  └─ 実際のソースコードで確認
```

---

## 💡 図の見方のコツ

### Mermaid 図の色分け
- 🟨 黄色: ユーザーインターフェース
- 🔵 青色: コア処理
- 🟣 紫色: 最適化・学習
- 🟢 緑色: データ保管

### 矢印の意味
- ➡️ 実線: データ/リクエストの流れ
- ⇢ 点線: 参照・取得

---

**Last Updated**: 2026-05-23

**次のステップ**: [README.md](README.md) でもっと詳しく学ぶ、または foundation_math/ (reference: ../../foundation_math/) で数学的背景を学ぶ
